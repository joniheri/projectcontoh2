<?php
    session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <?php include 'inc/head.php'; ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Header Navbar: style can be found in header.less -->
    <?php include 'inc/header.php'; ?>
    <!-- End Header Navbar-->
  </header>

  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel -->
      <?php include 'inc/sidebar-menu.php'; ?>
      <!-- End Sidebar user panel -->

    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <?php
      error_reporting(0);
      switch($_GET['page'])
      {
        // Dashboard
        default:
        include "pages/dashboard/dashboard2.php";
        break;
        //==================================================

        // Data Konsumen
        case "data_konsumen";
        include "pages/master_data/data_konsumen/data_konsumen.php";
        break;
        case "proses_hapus_data_konsumen";
        include "pages/master_data/data_konsumen/proses_hapus_data_konsumen.php";
        break;
        case "tambah_data_konsumen";
        include "pages/master_data/data_konsumen/tambah_data_konsumen.php";
        break;
        case "proses_simpan_tambah_data_konsumen";
        include "pages/master_data/data_konsumen/proses_simpan_tambah_data_konsumen.php";
        break;
        case "edit_data_konsumen";
        include "pages/master_data/data_konsumen/edit_data_konsumen.php";
        break;
        case "proses_simpan_edit_data_konsumen";
        include "pages/master_data/data_konsumen/proses_simpan_edit_data_konsumen.php";
        break;
        //==================================================

         // Data Teknisi
        case "data_teknisi";
        include "pages/master_data/data_teknisi/data_teknisi.php";
        break;
        case "proses_hapus_data_teknisi";
        include "pages/master_data/data_teknisi/proses_hapus_data_teknisi.php";
        break;
        case "tambah_data_teknisi";
        include "pages/master_data/data_teknisi/tambah_data_teknisi.php";
        break;
        case "proses_simpan_tambah_data_teknisi";
        include "pages/master_data/data_teknisi/proses_simpan_tambah_data_teknisi.php";
        break;
        case "edit_data_teknisi";
        include "pages/master_data/data_teknisi/edit_data_teknisi.php";
        break;
        case "proses_simpan_edit_data_teknisi";
        include "pages/master_data/data_teknisi/proses_simpan_edit_data_teknisi.php";
        break;
        //==================================================

        // Data Sparepart
        case "data_sparepart";
        include "pages/master_data/data_sparepart/data_sparepart.php";
        break;
        case "proses_hapus_data_sparepart";
        include "pages/master_data/data_sparepart/proses_hapus_data_sparepart.php";
        break;
        case "tambah_data_sparepart";
        include "pages/master_data/data_sparepart/tambah_data_sparepart.php";
        break;
        case "proses_simpan_tambah_data_sparepart";
        include "pages/master_data/data_sparepart/proses_simpan_tambah_data_sparepart.php";
        break;
        case "edit_data_sparepart";
        include "pages/master_data/data_sparepart/edit_data_sparepart.php";
        break;
        case "proses_simpan_edit_data_sparepart";
        include "pages/master_data/data_sparepart/proses_simpan_edit_data_sparepart.php";
        break;
        //==================================================

        // Data Kerusakan
        case "data_kerusakan";
        include "pages/master_data/data_kerusakan/data_kerusakan.php";
        break;
         case "proses_hapus_data_kerusakan";
        include "pages/master_data/data_kerusakan/proses_hapus_data_kerusakan.php";
        break;
        case "tambah_data_kerusakan";
        include "pages/master_data/data_kerusakan/tambah_data_kerusakan.php";
        break;
        case "proses_simpan_tambah_data_kerusakan";
        include "pages/master_data/data_kerusakan/proses_simpan_tambah_data_kerusakan.php";
        break;
        case "edit_data_kerusakan";
        include "pages/master_data/data_kerusakan/edit_data_kerusakan.php";
        break;
        case "proses_simpan_edit_data_kerusakan";
        include "pages/master_data/data_kerusakan/proses_simpan_edit_data_kerusakan.php";
        break;
        //==================================================

        // Servis Masuk
        case "servis_masuk";
        include "pages/transaksi/servis_masuk/servis_masuk.php";
        break;
        case "tambah_servis_masuk";
        include "pages/transaksi/servis_masuk/tambah_servis_masuk.php";
        break;
        case "proses_simpan_tambah_servis_masuk";
        include "pages/transaksi/servis_masuk/proses_simpan_tambah_servis_masuk.php";
        include "pages/transaksi/servis_masuk/cetak_servis_masuk.php";
        break;
        case "proses_hapus_servis_masuk";
        include "pages/transaksi/servis_masuk/proses_hapus_servis_masuk.php";
        break;
        case "edit_servis_masuk";
        include "pages/transaksi/servis_masuk/edit_servis_masuk.php";
        break;
        case "proses_simpan_edit_servis_masuk";
        include "pages/transaksi/servis_masuk/proses_simpan_edit_servis_masuk.php";
        break;
        case "button_cetak_servis_masuk";
        include "pages/transaksi/servis_masuk/button_cetak_servis_masuk.php";
        break;
        case "edit_status_servis";
        include "pages/transaksi/servis_masuk/edit_status_servis.php";
        break;
        case "tambah_servis_sparepart";
        include "pages/transaksi/servis_masuk/tambah_servis_sparepart.php";
        break;
        case "proses_simpan_tambah_servis_sparepart";
        include "pages/transaksi/servis_masuk/proses_simpan_tambah_servis_sparepart.php";
        break;
        case "proses_hapus_servis_sparepart";
        include "pages/transaksi/servis_masuk/proses_hapus_servis_sparepart.php";
        break;
        case "tambah_servis_kerusakan";
        include "pages/transaksi/servis_masuk/tambah_servis_kerusakan.php";
        break;
        case "proses_simpan_tambah_servis_kerusakan";
        include "pages/transaksi/servis_masuk/proses_simpan_tambah_servis_kerusakan.php";
        break;
        case "proses_hapus_servis_kerusakan";
        include "pages/transaksi/servis_masuk/proses_hapus_servis_kerusakan.php";
        break;
        case "proses_servis_selesai";
        include "pages/transaksi/servis_masuk/proses_servis_selesai.php";
        break;
        case "take_out";
        include "pages/transaksi/servis_masuk/take_out.php";
        break;
        //==================================================

        // Servis Keluar
        case "servis_keluar";
        include "pages/transaksi/servis_keluar/servis_keluar.php";
        break;
        case "tambah_servis_keluar2";
        include "pages/transaksi/servis_keluar/tambah_servis_keluar2.php";
        break;
        case "proses_simpan_tambah_servis_keluar2";
        include "pages/transaksi/servis_keluar/proses_simpan_tambah_servis_keluar2.php";
        break;
        case "tambah_sp_servis_keluar";
        include "pages/transaksi/servis_keluar/tambah_sp_servis_keluar.php";
        break;
        case "proses_hapus_servis_keluar";
        include "pages/transaksi/servis_keluar/proses_hapus_servis_keluar.php";
        break;
        case "edit_servis_keluar";
        include "pages/transaksi/servis_keluar/edit_servis_keluar.php";
        break;
        case "proses_simpan_edit_servis_keluar";
        include "pages/transaksi/servis_keluar/proses_simpan_edit_servis_keluar.php";
        break;
        //==================================================

        // Servis Keluar
        case "lap_servis_keluar";
        include "pages/laporan/lap_servis_keluar.php";
        break;
        case "cetak_lap_servis_keluar";
        include "pages/laporan/cetak_lap_servis_keluar.php";
        break;
        //==================================================

        // Icon contoh
        case "icon_contoh";
        include "pages/icon/icon_contoh.php";
        break;
        //==================================================

        }
        

    ?>
    <!-- End main content -->

  </div>
  <!-- End Content Wrapper. Contains page content -->

  <!-- footer -->
  <footer class="main-footer">
    <?php include 'inc/footer.php'; ?>
  </footer>
  <!-- end footer -->

</div>
<!-- ./wrapper -->

<?php include 'inc/inc-javascript2.php'; ?>

</body>
</html>