<?php
	session_start();
    $username_session       = $_SESSION['username'];
    $password_session       = $_SESSION['password'];
    $nama_pengguna_session  = $_SESSION['nama_pengguna'];
    $hak_akses_session      = $_SESSION['hak_akses'];

	if(!isset($username_session)){
	    echo "<script>alert('Silahkan login terlebih dahulu')</script>";
	    echo "<meta http-equiv='refresh' content='0; url=../index.php'>";
	}
	else {
?>

<!DOCTYPE html>
<html>
<head>
  <?php include 'inc/head2.php'; ?>
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <!-- Header Navbar: style can be found in header.less -->
    <?php include 'inc/header.php'; ?>
    <!-- End Header Navbar-->
  </header>

  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      <!-- Sidebar user panel -->
      <?php include 'inc/sidebar-menu.php'; ?>
      <!-- End Sidebar user panel -->

    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <?php
      error_reporting(0);
      switch($_GET['page'])
      {
        // Home
        default:
        include "pages/dashboard/dashboard2.php";
        break;
        //==================================================

        // Profile
        case "profile";
        include "pages/profile/profile.php";
        break;
        case "edit_profile";
        include "pages/profile/edit_profile.php";
        break;
        case "proses_simpan_edit_profile";
        include "pages/profile/proses_simpan_edit_profile.php";
        break;
        //==================================================

        // Data jenis surat
        case "data_jenis_surat";
        include "pages/master_data/data_jenis_surat/data_jenis_surat.php";
        break;
        case "tambah_data_jenis_surat";
        include "pages/master_data/data_jenis_surat/tambah_data_jenis_surat.php";
        break;
        case "proses_simpan_tambah_data_jenis_surat";
        include "pages/master_data/data_jenis_surat/proses_simpan_tambah_data_jenis_surat.php";
        break;
        case "proses_hapus_data_jenis_surat";
        include "pages/master_data/data_jenis_surat/proses_hapus_data_jenis_surat.php";
        break;
        case "edit_data_jenis_surat";
        include "pages/master_data/data_jenis_surat/edit_data_jenis_surat.php";
        break;
        case "proses_simpan_edit_data_jenis_surat";
        include "pages/master_data/data_jenis_surat/proses_simpan_edit_data_jenis_surat.php";
        break;
        //==================================================

        // Data pengguna
        case "data_pengguna";
        include "pages/master_data/data_pengguna/data_pengguna.php";
        break;
        case "tambah_data_pengguna";
        include "pages/master_data/data_pengguna/tambah_data_pengguna.php";
        break;
        case "proses_simpan_tambah_pengguna";
        include "pages/master_data/data_pengguna/proses_simpan_tambah_pengguna.php";
        break;
        case "proses_hapus_pengguna";
        include "pages/master_data/data_pengguna/proses_hapus_pengguna.php";
        break;
        case "edit_data_pengguna";
        include "pages/master_data/data_pengguna/edit_data_pengguna.php";
        break;
        case "proses_simpan_edit_pengguna";
        include "pages/master_data/data_pengguna/proses_simpan_edit_pengguna.php";
        break;
        //==================================================

        // Surat Masuk
        case "surat_masuk";
        include "pages/arsip_surat/surat_masuk/surat_masuk.php";
        break;
        case "tambah_surat_masuk";
        include "pages/arsip_surat/surat_masuk/tambah_surat_masuk.php";
        break;
        case "proses_simpan_tambah_surat_masuk";
        include "pages/arsip_surat/surat_masuk/proses_simpan_tambah_surat_masuk.php";
        break;
        case "proses_hapus_surat_masuk";
        include "pages/arsip_surat/surat_masuk/proses_hapus_surat_masuk.php";
        break;
        case "edit_surat_masuk";
        include "pages/arsip_surat/surat_masuk/edit_surat_masuk.php";
        break;
        case "proses_simpan_edit_surat_masuk";
        include "pages/arsip_surat/surat_masuk/proses_simpan_edit_surat_masuk.php";
        break;
        //==================================================

        // Surat Keluar
        case "surat_keluar";
        include "pages/arsip_surat/surat_keluar/surat_keluar.php";
        break;
        case "tambah_surat_keluar";
        include "pages/arsip_surat/surat_keluar/tambah_surat_keluar.php";
        break;
        case "proses_simpan_tambah_surat_keluar";
        include "pages/arsip_surat/surat_keluar/proses_simpan_tambah_surat_keluar.php";
        break;
        case "proses_hapus_surat_keluar";
        include "pages/arsip_surat/surat_keluar/proses_hapus_surat_keluar.php";
        break;
        case "edit_surat_keluar";
        include "pages/arsip_surat/surat_keluar/edit_surat_keluar.php";
        break;
        case "proses_simpan_edit_surat_keluar";
        include "pages/arsip_surat/surat_keluar/proses_simpan_edit_surat_keluar.php";
        break;
        //==================================================

        // Ajuan Surat
        case "ajuan_surat";
        include "pages/ajuan_surat/ajuan_surat.php";
        break;
        case "balas_ajuan_surat";
        include "pages/ajuan_surat/balas_ajuan_surat.php";
        break;
        case "proses_hapus_ajuan_surat";
        include "pages/ajuan_surat/proses_hapus_ajuan_surat.php";
        break;
        case "proses_simpan_balas_ajuan_surat";
        include "pages/ajuan_surat/proses_simpan_balas_ajuan_surat.php";
        break;
        //==================================================

        // Tanggapan Surat
        case "tanggapan_surat";
        include "pages/tanggapan_surat/tanggapan_surat.php";
        break;
        case "proses_hapus_tanggapan_surat";
        include "pages/tanggapan_surat/proses_hapus_tanggapan_surat.php";
        break;
        //==================================================

        // kelola pengumuman
        case "pengumuman";
        include "pages/pengumuman/pengumuman.php";
        break;
        case "tambah_pengumuman";
        include "pages/pengumuman/tambah_pengumuman.php";
        break;
        case "proses_simpan_tambah_pengumuman";
        include "pages/pengumuman/proses_simpan_tambah_pengumuman.php";
        break;
        case "proses_hapus_pengumuman";
        include "pages/pengumuman/proses_hapus_pengumuman.php";
        break;
        case "edit_pengumuman";
        include "pages/pengumuman/edit_pengumuman.php";
        break;
        case "proses_simpan_edit_pengumuman";
        include "pages/pengumuman/proses_simpan_edit_pengumuman.php";
        break;
        //==================================================

        // Laporan
        case "lap_surat_masuk";
        include "pages/laporan/lap_surat_masuk.php";
        break;
        case "cetak_lap_surat_masuk";
        include "pages/laporan/cetak_lap_surat_masuk.php";
        break;
        case "lap_surat_keluar";
        include "pages/laporan/lap_surat_keluar.php";
        break;
        case "cetak_lap_surat_keluar";
        include "pages/laporan/cetak_lap_surat_keluar.php";
        break;
        case "lap_ajuan_surat";
        include "pages/laporan/lap_ajuan_surat.php";
        break;
        case "cetak_lap_ajuan_surat";
        include "pages/laporan/cetak_lap_ajuan_surat.php";
        break;
        case "lap_tanggapan_surat";
        include "pages/laporan/lap_tanggapan_surat.php";
        break;
        case "cetak_lap_tanggapan_surat";
        include "pages/laporan/cetak_lap_tanggapan_surat.php";
        break;
        //==================================================
        
        }

    ?>
    <!-- End main content -->

  </div>
  <!-- End Content Wrapper. Contains page content -->

  <!-- footer -->
  <footer class="main-footer">
    <?php include 'inc/footer.php'; ?>
  </footer>
  <!-- end footer -->

</div>
<!-- ./wrapper -->

<?php include 'inc/inc-javascript2.php'; ?>

</body>
</html>

<?php } ?>