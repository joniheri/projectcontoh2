
<?php
/*
  $username_session       = $_SESSION['username'];
  $password_session       = $_SESSION['password'];
  $nama_pengguna_session  = $_SESSION['nama_pengguna'];
  $hak_akses_session      = $_SESSION['hak_akses'];

  include '../conn/koneksi.php';

  $query_user  = "SELECT * FROM tb_user WHERE username = '$username_session'";
  $sql_user    = mysql_query($query_user);
  $data_user   = mysql_fetch_array($sql_user);
  $total_user  = mysql_num_rows($sql_user);

  $username        = $data_user['username'];
  $password        = $data_user['password'];
  $nama_pengguna   = $data_user['nama_pengguna'];
  $hak_akses       = $data_user['hak_akses'];
  $file_name_foto  = $data_user['file_name_foto'];
*/
?>

<!-- sidebar menu: : style can be found in sidebar.less -->

<div class="user-panel">
  <div class="pull-left image">
    <img src="../admin/img/avatar5.png" class="img-circle" alt="User Image">
  </div>
  <div class="pull-left info">
    <p><?php echo 'Zakiy Muayyad';?></p>
    <a href="#"><i class="fa fa-circle text-success"></i> <?php echo 'Online'; ?></a>
  </div>
</div>

<!-- search form -->
<!--
<br>
<form action="#" method="get" class="sidebar-form">
  <div class="input-group">
    <input type="text" name="q" class="form-control" placeholder="Search...">
    <span class="input-group-btn">
      <button type="submit" name="search" id="search-btn" class="btn btn-flat"><i class="fa fa-search"></i></button>
    </span>
  </div>
</form>
-->

<ul class="sidebar-menu" data-widget="tree">
  
  <li class="header">MENU UTAMA</li>

  <!-- Dasboard -->
  <li><a href="index.php"><i class="fa fa-dashboard"></i> <span>Dasboard</span></a></li>
  <!-- End Dashboard -->

  <!-- Master Data -->
  <li class="treeview">
    <a href="#">
      <i class="fa fa-folder"></i> <span>Master Data</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="?page=data_konsumen"><i class="fa fa-circle-o"></i> Data Konsumen</a></li>
      <li><a href="?page=data_teknisi"><i class="fa fa-circle-o"></i> Data Teknisi</a></li>
      <li><a href="?page=data_sparepart"><i class="fa fa-circle-o"></i> Data Sparepart</a></li>
      <li><a href="?page=data_kerusakan"><i class="fa fa-circle-o"></i> Data Kerusakan</a></li>
    </ul>
  </li>
  <!-- End Master Data -->

  <!-- transaksi -->
  <li class="treeview">
    <a href="#">
      <i class="glyphicon glyphicon-stats"></i> <span>Transaksi</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="?page=servis_masuk"><i class="fa fa-circle-o"></i> Servis Masuk</a></li>
      <li><a href="?page=servis_keluar"><i class="fa fa-circle-o"></i> Servis Keluar</a></li>
    </ul>
  </li>
  <!-- End transaksi -->

  <!-- menu sms gateway -->
  <li class="header">MENU SMS GATEWAY</li>
  <li class="treeview">
    <a href="#">
      <i class="glyphicon glyphicon-envelope"></i> <span>SMS Gateway</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="?page=lap_surat_masuk"><i class="fa fa-circle-o"></i> Kirm SMS</a></li>
      <li><a href="?page=lap_surat_keluar"><i class="fa fa-circle-o"></i> SMS Masuk</a></li>
      <li><a href="?page=lap_ajuan_surat"><i class="fa fa-circle-o"></i> SMS Keluar</a></li>
      <li><a href="?page=lap_tanggapan_surat"><i class="fa fa-circle-o"></i> Pengaturan SMS</a></li>
    </ul>
  </li>
  <!-- end menu laporan -->

  <!-- menu laporan -->
  <li class="header">MENU LAPORAN</li>
  <li class="treeview">
    <a href="#">
      <i class="ion ion-stats-bars"></i> <span>Laporan</span>
      <span class="pull-right-container">
        <i class="fa fa-angle-left pull-right"></i>
      </span>
    </a>
    <ul class="treeview-menu">
      <li><a href="?page=lap_surat_masuk"><i class="fa fa-circle-o"></i> Lap. Servis Masuk</a></li>
      <li><a href="?page=lap_servis_keluar"><i class="fa fa-circle-o"></i> Lap. Servis Keluar</a></li>
    </ul>
  </li>
  <!-- end menu laporan -->

  <!-- Dasboard -->
  <li><a href="?page=icon_contoh"><i class="fa fa-dashboard"></i> <span>Icon Contoh</span></a></li>
  <!-- End Dashboard -->

</ul>