<strong>Copyright &copy; <?php echo date('Y') ?> <a href="https://joncode.blogspot.com">JonCode</a>.</strong> All rights reserved.
<div class="pull-right hidden-xs">
  <b>Version</b> 1.0
</div>