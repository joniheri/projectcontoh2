<?php
  include '../conn/koneksi.php';
  
  /*
  $query_user  = "SELECT * FROM tb_user WHERE username = '$username_session'";
  $sql_user    = mysql_query($query_user);
  $data_user   = mysql_fetch_array($sql_user);
  $total_user  = mysql_num_rows($sql_user);

  $username        = $data_user['username'];
  $password        = $data_user['password'];
  $nama_pengguna   = $data_user['nama_pengguna'];
  $hak_akses       = $data_user['hak_akses'];
  $file_name_foto   = $data_user['file_name_foto'];
  */

  $username_session       = $_SESSION['username'];
  $password_session       = $_SESSION['password'];
  $nama_user_session      = $_SESSION['nama_user'];
  $hak_akses_session      = $_SESSION['hak_akses'];
?>

<!-- Logo -->
<a href="index.php" class="logo">
  <!-- mini logo for sidebar mini 50x50 pixels -->
  <span class="logo-mini"><b>E</b>-S</span>
  <!-- logo for regular state and mobile devices -->
  <span class="logo-lg"><b>E-</b> <?php echo 'Service';?></span>
</a>
<!-- End Logo -->

<nav class="navbar navbar-static-top">
  <!-- Sidebar toggle button-->
  <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
    <span class="sr-only">Toggle navigation</span>
  </a>
  <div class="navbar-custom-menu">
    <ul class="nav navbar-nav">

      <!-- User Account: style can be found in dropdown.less -->
      <!-- <li><a href="../" target="_blank" title="Home"><i class="fa fa-home"></i> Home</a></li> -->
      <li class="dropdown user user-menu">
        <a href="#" class="dropdown-toggle" data-toggle="dropdown" title="Account">
          <img src="../admin/img/avatar5.png" class="user-image" alt="User Image">
          <span class="hidden-xs"><?php// echo $nama_pengguna;?></span>
          <span class="caret"></span>
        </a>
        <ul class="dropdown-menu">
          <!-- User image -->
          <li class="user-header">
            <img src="../admin/img/avatar5.png" class="img-circle" alt="User Image">
            <p>
              <span><?php echo $nama_user_session;?></span><br>
              <small><?php echo $hak_akses_session;?></small>
            </p>
          </li>
          <!-- Menu Footer-->
          <li class="user-footer">
            <div class="pull-left">
              <a href="?page=profile" class="btn btn-default btn-flat"><i class="fa fa-user"></i> Profile</a>
            </div>
            <div class="pull-right">
              <a href="logout.php" class="btn btn-default btn-flat"><i class="fa fa-sign-out"></i> Log Out</a>
            </div>
          </li>
        </ul>
      </li>
      <!-- End User Account -->
    </ul>
  </div>
</nav>