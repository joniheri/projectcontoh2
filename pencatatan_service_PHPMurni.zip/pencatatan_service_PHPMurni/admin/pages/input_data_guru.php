<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM TAMBAH JENIS SURAT</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_data_jenis_surat" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Kode Surat</label>
              <input type="text" class="form-control" name="kode_surat" id="" placeholder="Kode Surat" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Surat</label>
              <input type="text" class="form-control" name="nama_surat" id="" placeholder="Jenis Surat" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputFile">Upload File</label>
              <input type="file" name="file" id="exampleInputFile">
            </div>
          </div>
          <div class="col-md-6">
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_data_jenis_surat" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=data_jenis_surat" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>