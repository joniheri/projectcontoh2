
<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM TAMBAH DATA KONSUMEN</h3>
    </div>
<?php 
  include '../conn/koneksi.php';
  include '../conn/autoid.php';
?>
    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_data_konsumen" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">

              <input type="hidden" class="form-control" name="id_konsumen" value="<?= $auto_idk ?> " id="" placeholder="ID Konsumen">

            <div class="form-group">
              <label for="exampleInputPassword1">Nama Konsumen</label>
              <input type="text" class="form-control" name="nama_konsumen" id="" placeholder="Nama Konsumen" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Kelamin</label>
              <select name="jk" class="form-control select2" style="width: 100%;">
                <option selected="" value="Laki-Laki">Laki-Laki</option>
                <option selected="" value="Perempuan">Perempuan</option>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Alamat</label>
              <input type="text" class="form-control" name="alamat" id="" placeholder="Alamat" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">No Telepon</label>
              <input type="text" class="form-control" name="telp" id="" placeholder="No Telepon" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_data_konsumen" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=data_jenis_surat" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>