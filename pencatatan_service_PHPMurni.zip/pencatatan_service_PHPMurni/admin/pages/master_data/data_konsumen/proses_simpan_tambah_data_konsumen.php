<?php
	include '../conn/koneksi.php';


	$id_konsumen_post 		= $_POST['id_konsumen'];
	$nama_konsumen_post 	= strtoupper($_POST['nama']);
	$jk_post 				= $_POST['jk'];
	$alamat_post 			= strtoupper($_POST['alamat']);
	$telp_post 				= $_POST['telp'];

	//echo "$id_konsumen_post, $nama_konsumen_post, $jk_post, $alamat_post, $telp_post";
	
	$query_id_konsumen=mysql_query("SELECT * FROM tbkonsumen where id_konsumen='$id_konsumen_post'");
	$cek=mysql_num_rows($query_id_konsumen);
	if ($cek>0) {
		echo "<script> alert('Maaf, ID Konsumen : $id_konsumen_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_konsumen'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbkonsumen
			(
			id_konsumen, 
			nama,
			jk,
			alamat,
			telp
			) 
			values
			(
			'$id_konsumen_post',
			'$nama_konsumen_post',
			'$jk_post',
			'$alamat_post',
			'$telp_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_konsumen'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_konsumen'>";	
		}
	}
?>