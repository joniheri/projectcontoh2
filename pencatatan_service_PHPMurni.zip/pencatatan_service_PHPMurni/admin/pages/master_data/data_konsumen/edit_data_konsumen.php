<?php
	include '../conn/koneksi.php';

	$id_kon_get = $_GET['id_kon_kirim'];

	$query         = "SELECT * FROM tbkonsumen WHERE id_konsumen='$id_kon_get'";
	$sql           = mysql_query($query);
	$data          = mysql_fetch_array($sql);
	$id_konsumen   = $data['id_konsumen'];
	$nama_konsumen = $data['nama'];
  $jk            = $data['jk'];
  $alamat        = $data['alamat'];
  $telp          = $data['telp'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM EDIT DATA KONSUMEN</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_data_konsumen&id_kon_kirim=<?php echo $id_kon_get;?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">ID Konsumen</label>
              <input type="text" class="form-control" name="id_konsumen" value="<?php echo $id_kon_get; ?>" id="" placeholder="ID Konsumen" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Nama Konsumen</label>
              <input type="text" class="form-control" name="nama_konsumen" value="<?php echo $nama_konsumen; ?>" id="" placeholder="Nama Konsumen" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Kelamin</label>
              <select name="jk" class="form-control select2" style="width: 100%;">
                <?php
                  $jk_laki_laki;
                  $jk_perempuan;
                  if($jk == "Laki-Laki"){
                    $jk_laki_laki='<option selected="selected" value="Laki-Laki">Laki-Laki</option>';
                    $jk_perempuan='<option value="Perempuan">Perempuan</option>';
                  }
                  else if($jk == "Perempuan"){
                    $jk_laki_laki='<option value="Laki-Laki">Laki-Laki</option>';
                    $jk_perempuan='<option selected="selected" value="Perempuan">Perempuan</option>';
                  }
                ?>
                <?php
                  echo $jk_laki_laki;
                  echo $jk_perempuan;
                ?>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Alamat</label>
              <input type="text" class="form-control" name="alamat" value="<?php echo $alamat; ?>" id="" placeholder="Alamat" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">No Telepon</label>
              <input type="text" class="form-control" name="telp" value="<?php echo $telp; ?>" id="" placeholder="No Telepon" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=data_konsumen" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>