<?php
	include '../conn/koneksi.php';

	$id_kon_get = $_GET['id_kon_get'];

	//echo $id_kon_get;

	
	$query 	= mysql_query("DELETE FROM tbkonsumen WHERE id_konsumen='$id_kon_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_konsumen'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_konsumen'>";
	}
	
	
?>