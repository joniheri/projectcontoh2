<?php
	/*
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	*/
	include '../conn/koneksi.php';

	$id_kon_get 			= $_GET['id_kon_kirim'];

	$id_konsumen_post 		= $_POST['id_konsumen'];
	$nama_konsumen_post 	= strtoupper($_POST['nama']);
	$jk_post 				= $_POST['jk'];
	$alamat_post 			= strtoupper($_POST['alamat']);
	$telp_post 				= $_POST['telp'];

	//echo 'ID Awal : '.$id_kon_get.'<br> ID Akhir : '.$id_konsumen_post;

	if($id_konsumen_post == $id_kon_get){
		$input=mysql_query("
			UPDATE tbkonsumen SET
			nama='$nama_konsumen_post',
			jk='$jk_post',
			alamat='$alamat_post',
			telp='$telp_post'
			WHERE id_konsumen='$id_kon_get'
		");
		if ($input) {
			echo "<script> alert('Update data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_konsumen'>";	
		}
		else {
			echo "<script> alert('Update data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_konsumen&id_kon_kirim=$id_kon_get'>";	
		}
	}

	else{
		$query_id_konsumen=mysql_query("SELECT * FROM tbkonsumen where id_konsumen='$id_konsumen_post'");
		$cek=mysql_num_rows($query_id_konsumen);
		if ($cek>0) {
			echo "<script> alert('Maaf, ID Konsumen : $id_konsumen_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_konsumen&id_kon_kirim=$id_kon_get'>";
		}

		else{
			$input=mysql_query("
				UPDATE tbkonsumen SET
				id_konsumen='$id_konsumen_post',
				nama='$nama_konsumen_post',
				jk='$jk_post',
				alamat='$alamat_post',
				telp='$telp_post'
				WHERE id_konsumen='$id_kon_get'
			");
			if ($input) {
				echo "<script> alert('Update data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=data_konsumen'>";	
			}
			else {
				echo "<script> alert('Update data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_konsumen&id_kon_kirim=$id_kon_get'>";	
			}
		}
	}

?>
