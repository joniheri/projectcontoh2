<?php
  include '../conn/koneksi.php';
  $cari_post = $_POST['cari'];
?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">DATA KONSUMEN</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=data_konsumen">
        <div class="box-header">
          <a style="margin-right: 5px;" href="?page=tambah_data_konsumen" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
          <div class="box-tools">
            <div class="input-group input-group-sm" style="width: 150px;">
              <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </div>
        </div>
      </form>
      <!-- /.box-header -->

      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr style="background-color: #7DB3D2;">
            <th width="120">Id Konsumen</th>
            <th>Nama Konsumen</th>
            <th width="100">JK</th>
            <th>Alamat</th>
            <th width="100">Telepon</th>
            <th width="100">Aksi</th>
          </tr>
          <?php
            $query  = "
              SELECT * FROM tbkonsumen 
              ORDER by id_konsumen asc
            ";
            $sql    = mysql_query($query);
            $total  = mysql_num_rows($sql);
            $no     = 1;
            
            while ($data=mysql_fetch_array($sql)) {
              $file = $data['file'];
          ?>
          <tr>
            <td><?php echo $data['id_konsumen']; ?></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['jk']; ?></td>
            <td><?php echo $data['alamat']; ?></td>
            <td><?php echo $data['telp']; ?></td>
            <td> 
              <a class="btn btn-warning btn-default" style="color: #ffffff;" title="Edit" href="?page=edit_data_konsumen&id_kon_kirim=<?php echo $data['id_konsumen']; ?>"><i class="fa fa-pencil"></i></a>
              <a class="btn btn-danger  btn-default" style="color: #ffffff;" title="Hapus" href="?page=proses_hapus_data_konsumen&id_kon_get=<?php echo $data['id_konsumen']; ?>" onClick="return confirm('Yakin ingin menghapus data dengan ID Konsumen : <?php echo $data['id_konsumen']; ?>...?');"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
          <?php $no++; } ?>
        </table>
      </div>
    </div>
    <!-- /.box-body -->
  </div>
</section>