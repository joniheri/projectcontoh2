<?php
	include '../conn/koneksi.php';

	$id_spr_get = $_GET['id_spr_kirim'];

	$query          = "SELECT * FROM tbsparepart WHERE id_sp='$id_spr_get'";
	$sql            = mysql_query($query);
	$data           = mysql_fetch_array($sql);
	$id_sparepart   = $data['id_sp'];
	$nama_sparepart = $data['nama_sp'];
  $jenis          = $data['jenis_sp'];
  $harga          = $data['harga_sp'];
  $qty            = $data['qty'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM EDIT DATA SPAREPART</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_data_sparepart&id_spr_kirim=<?php echo $id_spr_get;?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">ID Sparepart</label>
              <input type="text" class="form-control" name="id_sparepart" value="<?php echo $id_spr_get; ?>" id="" placeholder="ID Sparepart" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Nama Sparepart</label>
              <input type="text" class="form-control" name="nama_sparepart" value="<?php echo $nama_sparepart; ?>" id="" placeholder="Nama Sparepart" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Sparepart</label>
              <input type="text" class="form-control" name="jenis" value="<?php echo $jenis; ?>" id="" placeholder="Jenis" required="required">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Harga</label>
              <input type="text" class="form-control" name="harga" value="<?php echo $harga; ?>" id="" placeholder="Harga" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Stok</label>
              <input type="text" class="form-control" name="qty" value="<?php echo $qty; ?>" id="" placeholder="Stok" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=data_sparepart" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>