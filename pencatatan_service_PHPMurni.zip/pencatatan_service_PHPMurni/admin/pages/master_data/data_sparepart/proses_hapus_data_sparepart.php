<?php
	include '../conn/koneksi.php';

	$id_sparepart_get = $_GET['id_sp_get'];

	//echo $id_sparepart_get;

	
	$query 	= mysql_query("DELETE FROM tbsparepart WHERE id_sp='$id_sparepart_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_sparepart'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_sparepart'>";
	}
	
?>