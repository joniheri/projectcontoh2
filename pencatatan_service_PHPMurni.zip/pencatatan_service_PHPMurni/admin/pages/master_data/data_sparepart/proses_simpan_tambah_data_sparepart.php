<?php
	include '../conn/koneksi.php';


	$id_sparepart_post 		= $_POST['id_sparepart'];
	$nama_sparepart_post 	= strtoupper($_POST['nama_sparepart']);
	$jenis_sparepart_post 	= strtoupper($_POST['jenis']);
	$harga_post 			= $_POST['harga'];
	$qty_post 				= $_POST['qty'];

	//echo "$id_konsumen_post, $nama_konsumen_post, $jk_post, $alamat_post, $telp_post";
	
	$query_id_sparepart=mysql_query("SELECT * FROM tbsparepart where id_sp='$id_sparepart_post'");
	$cek=mysql_num_rows($query_id_sparepart);
	if ($cek>0) {
		echo "<script> alert('Maaf, ID Sparepart : $id_sparepart_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_sparepart'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbsparepart
			(
			id_sp, 
			nama_sp,
			jenis_sp,
			harga_sp,
			qty
			) 
			values
			(
			'$id_sparepart_post',
			'$nama_sparepart_post',
			'$jenis_sparepart_post',
			'$harga_post',
			'$qty_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_sparepart'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_sparepart'>";	
		}
	}
?>