<?php
	/*
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	*/
	include '../conn/koneksi.php';

	$id_spr_get 			= $_GET['id_spr_kirim'];

	$id_sparepart_post 		= $_POST['id_sparepart'];
	$nama_sparepart_post 	= strtoupper($_POST['nama_sparepart']);
	$jenis_post 			= strtoupper($_POST['jenis']);
	$harga_post 			= $_POST['harga'];
	$qty_post 				= $_POST['qty'];

	//echo 'ID Awal : '.$id_kon_get.'<br> ID Akhir : '.$id_konsumen_post;

	if($id_sparepart_post == $id_spr_get){
		$input=mysql_query("
			UPDATE tbsparepart SET
			nama_sp 	='$nama_sparepart_post',
			jenis_sp 	='$jenis_post',
			harga_sp 	='$harga_post',
			qty 		='$qty_post'
			WHERE  id_sp='$id_spr_get'
		");
		if ($input) {
			echo "<script> alert('Update data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_sparepart'>";	
		}
		else {
			echo "<script> alert('Update data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_sparepart&id_spr_kirim=$id_spr_get'>";	
		}
	}

	else{
		$query_id_sparepart=mysql_query("SELECT * FROM tbsparepart where id_sp='$id_sparepart_post'");
		$cek=mysql_num_rows($query_id_sparepart);
		if ($cek>0) {
			echo "<script> alert('Maaf, ID Sparepart : $id_sparepart_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_sparepart&id_spr_kirim=$id_spr_get'>";
		}

		else{
			$input=mysql_query("
				UPDATE tbsparepart SET
				id_sp 		='$id_sparepart_post',
				nama_sp 	='$nama_sparepart_post',
				jenis_sp 	='$jenis_post',
				harga_sp 	='$harga_post'
				qty 		='$qty_post'
				WHERE  id_sp='$id_spr_get'
			");
			if ($input) {
				echo "<script> alert('Update data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=data_sparepart'>";	
			}
			else {
				echo "<script> alert('Update data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_sparepart&id_spr_kirim=$id_spr_get'>";
			}
		}
	}

?>
