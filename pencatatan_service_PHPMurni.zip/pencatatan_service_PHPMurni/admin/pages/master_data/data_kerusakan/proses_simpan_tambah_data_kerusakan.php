<?php
	include '../conn/koneksi.php';


	$id_kerusakan_post 		= $_POST['id_kerusakan'];
	$jenis_kerusakan_post 	= strtoupper($_POST['jenis_kerusakan']);
	$harga_post 			= $_POST['harga'];

	//echo "$id_konsumen_post, $nama_konsumen_post, $jk_post, $alamat_post, $telp_post";
	
	$query_id_kerusakan=mysql_query("SELECT * FROM tbkerusakan where id_kerusakan='$id_kerusakan_post'");
	$cek=mysql_num_rows($query_id_kerusakan);
	if ($cek>0) {
		echo "<script> alert('Maaf, ID Kerusakan : $id_kerusakan_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_kerusakan'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbkerusakan
			(
			id_kerusakan, 
			nama_kerusakan,
			harga_kerusakan
			) 
			values
			(
			'$id_kerusakan_post',
			'$jenis_kerusakan_post',
			'$harga_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_kerusakan'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_kerusakan'>";	
		}
	}
?>