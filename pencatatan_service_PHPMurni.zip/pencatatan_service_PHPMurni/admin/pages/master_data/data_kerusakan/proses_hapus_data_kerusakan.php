<?php
	include '../conn/koneksi.php';

	$id_rsk_get = $_GET['id_rsk_get'];

	//echo $id_rsk_get;

	
	$query 	= mysql_query("DELETE FROM tbkerusakan WHERE id_kerusakan='$id_rsk_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_kerusakan'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_kerusakan'>";
	}
	
?>