<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM TAMBAH DATA KERUSAKAN</h3>
    </div>
<?php 
  include '../conn/koneksi.php';
  include '../conn/autoid.php';
?>
    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_data_kerusakan" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            
              <input type="hidden" class="form-control" name="id_kerusakan" value="<?= $auto_idrsk ?>" id="" placeholder="ID Kerusakan">

            <div class="form-group">
              <label for="exampleInputPassword1">Jenis kerusakan</label>
              <input type="text" class="form-control" name="jenis_kerusakan" id="" placeholder="Jenis Kerusakan" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Harga</label>
              <input type="text" class="form-control" name="harga" id="" placeholder="Harga" required="required">
            </div>
          </div>
          <div class="col-md-6">
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_data_kerusakan" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=data_kerusakan" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>