<?php
	/*
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	*/
	include '../conn/koneksi.php';

	$id_rsk_get 			= $_GET['id_rsk_kirim'];

	$id_kerusakan_post 		= $_POST['id_kerusakan'];
	$jenis_kerusakan_post 	= strtoupper($_POST['jenis_kerusakan']);
	$harga_post 			= $_POST['harga'];

	//echo 'ID Awal : '.$id_kon_get.'<br> ID Akhir : '.$id_konsumen_post;

	if($id_kerusakan_post == $id_rsk_get){
		$input=mysql_query("
			UPDATE tbkerusakan SET
			nama_kerusakan='$jenis_kerusakan_post',
			harga_kerusakan='$harga_post'
			WHERE id_kerusakan='$id_rsk_get'
		");
		if ($input) {
			echo "<script> alert('Update data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_kerusakan'>";	
		}
		else {
			echo "<script> alert('Update data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_kerusakan&id_rsk_kirim=$id_rsk_get'>";	
		}
	}

	else{
		$query_id_kerusakan=mysql_query("SELECT * FROM tbkerusakan where id_kerusakan='$id_kerusakan_post'");
		$cek=mysql_num_rows($query_id_kerusakan);
		if ($cek>0) {
			echo "<script> alert('Maaf, ID Kerusakan : $id_kerusakan_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_kerusakan&id_rsk_kirim=$id_rsk_get'>";
		}

		else{
			$input=mysql_query("
				UPDATE tbkerusakan SET
				id_kerusakan='$id_kerusakan_post',
				nama_kerusakan='$jenis_kerusakan_post',
				harga_kerusakan='$harga_post'
				WHERE id_kerusakan='$id_rsk_get'
			");
			if ($input) {
				echo "<script> alert('Update data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=data_kerusakan'>";	
			}
			else {
				echo "<script> alert('Update data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_kerusakan&id_rsk_kirim=$id_rsk_get'>";
			}
		}
	}

?>
