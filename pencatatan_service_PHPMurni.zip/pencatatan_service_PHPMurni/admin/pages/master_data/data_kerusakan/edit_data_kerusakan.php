<?php
	include '../conn/koneksi.php';

	$id_rsk_get      = $_GET['id_rsk_kirim'];

	$query           = "SELECT * FROM tbkerusakan WHERE id_kerusakan='$id_rsk_get'";
	$sql             = mysql_query($query);
	$data            = mysql_fetch_array($sql);
	$id_kerusakan    = $data['id_kerusakan'];
	$jenis_kerusakan = $data['nama_kerusakan'];
  $harga           = $data['harga_kerusakan'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM EDIT DATA KERUSAKAN</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_data_kerusakan&id_rsk_kirim=<?php echo $id_rsk_get;?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">ID kerusakan</label>
              <input type="text" class="form-control" name="id_kerusakan" value="<?php echo $id_rsk_get;?>" id="" placeholder="ID Kerusakan" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis kerusakan</label>
              <input type="text" class="form-control" name="jenis_kerusakan" value="<?php echo $jenis_kerusakan;?>" id="" placeholder="Jenis Kerusakan" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Harga Jasa</label>
              <input type="text" class="form-control" name="harga" value="<?php echo $harga;?>" id="" placeholder="Harga" required="required">
            </div>
          </div>
          <div class="col-md-6">
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=data_kerusakan" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>