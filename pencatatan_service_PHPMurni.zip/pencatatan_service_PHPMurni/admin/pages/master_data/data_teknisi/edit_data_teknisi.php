<?php
	include '../conn/koneksi.php';

	$id_tek_get = $_GET['id_tek_kirim'];

	$query         = "SELECT * FROM tbteknisi WHERE id_teknisi='$id_tek_get'";
	$sql           = mysql_query($query);
	$data          = mysql_fetch_array($sql);
	$id_teknisi    = $data['id_teknisi'];
	$nama_teknisi  = $data['nama_teknisi'];
  $jk            = $data['jk_teknisi'];
  $alamat        = $data['alamat_teknisi'];
  $telp          = $data['telp_teknisi'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM EDIT DATA TEKNISI</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_data_teknisi&id_tek_kirim=<?php echo $id_tek_get;?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">ID Teknisi</label>
              <input type="text" class="form-control" name="id_teknisi" value="<?php echo $id_tek_get; ?>" id="" placeholder="ID Teknisi" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Nama Teknisi</label>
              <input type="text" class="form-control" name="nama_teknisi" value="<?php echo $nama_teknisi; ?>" id="" placeholder="Nama Teknisi" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Kelamin</label>
              <select name="jk" class="form-control select2" style="width: 100%;">
                <?php
                  $jk_laki_laki;
                  $jk_perempuan;
                  if($jk == "Laki-Laki"){
                    $jk_laki_laki='<option selected="selected" value="Laki-Laki">Laki-Laki</option>';
                    $jk_perempuan='<option value="Perempuan">Perempuan</option>';
                  }
                  else if($jk == "Perempuan"){
                    $jk_laki_laki='<option value="Laki-Laki">Laki-Laki</option>';
                    $jk_perempuan='<option selected="selected" value="Perempuan">Perempuan</option>';
                  }
                ?>
                <?php
                  echo $jk_laki_laki;
                  echo $jk_perempuan;
                ?>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Alamat</label>
              <input type="text" class="form-control" name="alamat" value="<?php echo $alamat; ?>" id="" placeholder="Alamat" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">No Telepon</label>
              <input type="text" class="form-control" name="telp" value="<?php echo $telp; ?>" id="" placeholder="No Telepon" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=data_teknisi" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>