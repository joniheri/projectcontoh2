<?php
  include '../conn/koneksi.php';

  $cari_post = $_POST['cari'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">DATA TEKNISI</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=data_teknisi">
        <div class="box-header">
          <a style="margin-right: 5px;" href="?page=tambah_data_teknisi" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
          <div class="box-tools">
            <div class="input-group input-group-sm" style="width: 150px;">
              <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </div>
        </div>
      </form>
      <!-- /.box-header -->

      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr style="background-color: #7DB3D2;">
            <th width="120">Id Teknisi</th>
            <th>Nama Teknisi</th>
            <th width="100">JK</th>
            <th>Alamat</th>
            <th width="100">Telepon</th>
            <th width="100">Aksi</th>
          </tr>
          <?php
            $query  = "
              SELECT * FROM tbteknisi 
              ORDER by id_teknisi asc
            ";
            $sql    = mysql_query($query);
            $total  = mysql_num_rows($sql);
            $no     = 1;
            
            while ($data=mysql_fetch_array($sql)) {
              $file = $data['file'];
          ?>
          <tr>
            <td><?php echo $data['id_teknisi']; ?></td>
            <td><?php echo $data['nama_teknisi']; ?></td>
            <td><?php echo $data['jk_teknisi']; ?></td>
            <td><?php echo $data['alamat_teknisi']; ?></td>
            <td><?php echo $data['telp_teknisi']; ?></td>
            <td> 
              <a class="btn btn-warning btn-default" style="color: #ffffff;" title="Edit" href="?page=edit_data_teknisi&id_tek_kirim=<?php echo $data['id_teknisi']; ?>"><i class="fa fa-pencil"></i></a>
              <a class="btn btn-danger  btn-default" style="color: #ffffff;" title="Hapus" href="?page=proses_hapus_data_teknisi&id_tek_get=<?php echo $data['id_teknisi']; ?>" onClick="return confirm('Yakin ingin menghapus data dengan ID Teknisi : <?php echo $data['id_teknisi']; ?>...?');"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
          <?php $no++; } ?>
        </table>
      </div>
    </div>
    <!-- /.box-body -->
  </div>
</section>