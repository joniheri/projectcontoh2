<?php
	include '../conn/koneksi.php';


	$id_teknisi_post 		= $_POST['id_teknisi'];
	$nama_teknisi_post 		= strtoupper($_POST['nama_teknisi']);
	$jk_post 				= $_POST['jk'];
	$alamat_post 			= strtoupper($_POST['alamat']);
	$telp_post 				= $_POST['telp'];

	//echo "$id_konsumen_post, $nama_konsumen_post, $jk_post, $alamat_post, $telp_post";
	
	$query_id_teknisi=mysql_query("SELECT * FROM tbteknisi where id_teknisi='$id_teknisi_post'");
	$cek=mysql_num_rows($query_id_teknisi);
	if ($cek>0) {
		echo "<script> alert('Maaf, ID Teknisi : $id_teknisi_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_teknisi'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbteknisi
			(
			id_teknisi, 
			nama_teknisi,
			jk_teknisi,
			alamat_teknisi,
			telp_teknisi
			) 
			values
			(
			'$id_teknisi_post',
			'$nama_teknisi_post',
			'$jk_post',
			'$alamat_post',
			'$telp_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_teknisi'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_teknisi'>";	
		}
	}
?>