<?php
	include '../conn/koneksi.php';

	$id_tek_get = $_GET['id_tek_get'];

	//echo $id_tek_get;

	
	$query 	= mysql_query("DELETE FROM tbteknisi WHERE id_teknisi='$id_tek_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_teknisi'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=data_teknisi'>";
	}
	
?>