<?php
	/*
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	*/
	include '../conn/koneksi.php';

	$id_tek_get 			= $_GET['id_tek_kirim'];

	$id_teknisi_post 		= $_POST['id_teknisi'];
	$nama_teknisi_post 		= strtoupper($_POST['nama_teknisi']);
	$jk_post 				= $_POST['jk'];
	$alamat_post 			= strtoupper($_POST['alamat']);
	$telp_post 				= $_POST['telp'];

	//echo 'ID Awal : '.$id_kon_get.'<br> ID Akhir : '.$id_konsumen_post;

	if($id_teknisi_post == $id_tek_get){
		$input=mysql_query("
			UPDATE tbteknisi SET
			nama_teknisi='$nama_teknisi_post',
			jk_teknisi='$jk_post',
			alamat_teknisi='$alamat_post',
			telp_teknisi='$telp_post'
			WHERE id_teknisi='$id_tek_get'
		");
		if ($input) {
			echo "<script> alert('Update data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=data_teknisi'>";	
		}
		else {
			echo "<script> alert('Update data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_teknisi&id_tek_kirim=$id_tek_get'>";	
		}
	}

	else{
		$query_id_teknisi=mysql_query("SELECT * FROM tbteknisi where id_teknisi='$id_teknisi_post'");
		$cek=mysql_num_rows($query_id_teknisi);
		if ($cek>0) {
			echo "<script> alert('Maaf, ID Teknisi : $id_teknisi_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_teknisi&id_tek_kirim=$id_tek_get'>";
		}

		else{
			$input=mysql_query("
				UPDATE tbteknisi SET
				id_teknisi='$id_teknisi_post',
				nama_teknisi='$nama_teknisi_post',
				jk_teknisi='$jk_post',
				alamat_teknisi='$alamat_post',
				telp_teknisi='$telp_post'
				WHERE id_teknisi='$id_tek_get'
			");
			if ($input) {
				echo "<script> alert('Update data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=data_teknisi'>";	
			}
			else {
				echo "<script> alert('Update data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_data_teknisi&id_tek_kirim=$id_tek_get'>";
			}
		}
	}

?>
