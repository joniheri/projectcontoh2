<?php

  include '../conn/koneksi.php';
  
  /*
  $no_servis_get  = $_GET['no_srv_kirim'];

  $query_servis    = "SELECT tbservis.*, 
      tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
      FROM tbservis
      INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen) 
      WHERE no_servis='$no_servis_get'
  ";
  $sql_servis       = mysql_query($query_servis);
  $data_servis      = mysql_fetch_array($sql_servis);
  $no_servis_servis = $data_servis['no_servis'];
  $nama_konsumen    = $data_servis['nama'];
  $no_telp_konsumen = $data_servis['telp'];
  */

?>


<body onLoad="window.print();">
  <section class="content" style="background-color: #fff;">
    <div class="">
      <table>
        <tr>
          <td style="width: 500px;"><h4>CV. BASIS COMPUTER</h4></td>
          <td><?php echo ''; ?></td>
        </tr>
        <tr>
          <td style="width: 500px;">Jl. Raya Siteba no 47</td>
          <td>Tgl: <?php echo date('d-m-Y'); ?></td>
        </tr>
        <tr>
          <td style="width: 500px;">No Telp: 081363780075</td>
          <td><?php echo ' '; ?></td>
        </tr>
        <tr>
          <td style="width: 500px;">www.basisconputer.com</td>
          <td><?php echo ''; ?></td>
        </tr>
        <tr>
          <td>
            
          </td>
          <td>
            
          </td>
        </tr>
      </table>
      <hr style="margin-top: 8px;">
      <h4 align="center" style="margin-bottom: -20px; margin-top: -15px;">LAPORAN SERVIS KELUAR</h4>
      <!-- /.box-header -->
      <div class="box-body">
        <div class="box-header">
          <div class="box-tools">
            
          </div>
        </div>
        <!-- /.box-header -->
        <div class="box-body table-responsive no-padding">
          <table class="table table-hover">
            <tr style="background-color: #222D32; color: #ACB2B7">
              <th width="100" style="vertical-align: middle; text-align: center;">No Servis</th>
              <th width="150" style="vertical-align: middle; text-align: center;">Nama Konsumen</th>
              <th width="120" style="vertical-align: middle; text-align: center;">Nama Barang</th>
              <th width="100" style="vertical-align: middle; text-align: center;">Tgl Masuk</th>
              <th width="100" style="vertical-align: middle; text-align: center;">Tgl Keluar</th>
            </tr>
            <?php
            /*
              $query  = "
                SELECT * FROM tbskeluar 
                ORDER by id_keluar asc
              ";
              $sql    = mysql_query($query);
              $total  = mysql_num_rows($sql);
              $no     = 1;
              
              while ($data=mysql_fetch_array($sql)) {
                $file = $data['file'];
                */

              $query  = "SELECT tbservis.*, 
                        tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
                        FROM tbservis
                        INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen)
                        WHERE status ='Telah Diambil'
                        ORDER BY no_servis ASC
              ";
              $sql    = mysql_query($query);
              $total  = mysql_num_rows($sql);
              $no     = 1;
              
              while ($data=mysql_fetch_array($sql)) {
                $file = $data['file'];
            ?>
            <tr>
              <td><?php echo $data['no_servis']; ?></td>
              <td><?php echo $data['nama']; ?></td>
              <td><?php echo $data['nama_barang']; ?></td>
              <td><?php echo $data['tgl_masuk']; ?></td>
              <td><?php echo $data['tgl_keluar']; ?></td>
            </tr>
            <?php $no++; } ?>
          </table>
          <hr style="margin-top: 8px;">
          <table align="center">
            <tr>
              <td align="center" style=""></td>
              <td style="width: 400px;"></td>
              <td align="center">Hormat Saya</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td align="center" style=""></td>
              <td style="width: 400px;"></td>
              <td align="center">Admin</td>
            </tr>
          </table>
        </div>
      </div>
      <!-- /.box-body -->
    </div>
  </section>
</body>