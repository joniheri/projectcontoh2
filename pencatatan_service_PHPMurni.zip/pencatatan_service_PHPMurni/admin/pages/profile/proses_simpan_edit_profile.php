<?php
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	
	include '../conn/koneksi.php';
	$query_user  = "SELECT * FROM tb_user WHERE username = '$username_session'";
	$sql_user    = mysql_query($query_user);
	$data_user   = mysql_fetch_array($sql_user);
	$total_user  = mysql_num_rows($sql_user);

	$username 		= $data_user['username'];
	$password 		= $data_user['password'];
	$nama_pengguna	= $data_user['nama_pengguna'];
	$hak_akses 		= $data_user['hak_akses'];
	$file_name_foto = $data_user['file_name_foto'];

	$username_post 	= $_POST['username'];
	$password_post	= $_POST['password'];
	$nama_post		= $_POST['nama_pengguna'];
	$file_post		= $_POST['file'];

	$nama_photo = $_FILES['file']['name'];
	$type 		= $_FILES['file']['type'];
	$ukuran 	= $_FILES['file']['size'];

	/*
	echo 'Username : '.$username_post
	.'<br> Password : '.$password_post
	;
	*/

	//jika username sama
	if ($username_post == $username_session) {

		//jika foto tidak diinput
		if ($nama_photo == ""){
			$input=mysql_query("
				UPDATE tb_user SET 
				password 			= '$password', 
				nama_pengguna 		= '$nama_post'
				WHERE username 		= '$username_session'
			");
			if ($input) {
				echo "<script> alert('Edit data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=profile'>";	
			}
			else {
				echo "<script> alert('Edit data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";	
			}
		}
		//jika foto tidak diinput=========

		//jika foto diinput
		else if($nama_photo != ""){
			if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png") {
				echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG dan GIF saja.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";
			}
			else{
				$uploaddir='../files/';
				$rnd=date(His);				
				$nama_file_upload=$rnd.'-'.$nama_photo;
				$alamatfile=$uploaddir.$nama_file_upload;
				
				if (move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
					$input=mysql_query("
						UPDATE tb_user SET 
						password 			= '$password', 
						nama_pengguna 		= '$nama_post', 
						file_name_foto 		= '$nama_file_upload'
						WHERE username 		= '$username_session'
					");
						
					if ($input) {
						echo "<script> alert('Edit data BERHASIL.') </script>";
						echo "<meta http-equiv='refresh' content='0; url=?page=profile'>";	
					}
					else {
						echo "<script> alert('Edit data GAGAL.') </script>";
						echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";	
					}
				}
				else{
					echo "<script> alert('Proses upload gagal, kode error = " . $_FILES['location']['error'].".') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";
				}
			}
		}
		//batas jika foto tidak diinput=========
	}
	//batas jika username sama===============

	//jika username diganti
	else{
		$query_id_guru 	=mysql_query("SELECT * FROM tb_user where username='$username_post'");
		$cek_id_guru 	=mysql_num_rows($query_id_guru);
		if($cek_id_guru>0){
			echo "<script> alert('Maaf, Username : $username_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";
		}
		else{

			//jika foto tidak diinput
			if ($nama_photo == ""){
				$input=mysql_query("
					UPDATE tb_user SET 
					password 			= '$password', 
					nama_pengguna 		= '$nama_post'
					WHERE username 		= '$username_session'
				");
				if ($input) {
					echo "<script> alert('Edit data BERHASIL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=profile'>";	
				}
				else {
					echo "<script> alert('Edit data GAGAL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";	
				}
			}
			//batas jika foto tidak diinput===============

			//jika foto diinput
			else if($nama_photo != ""){
				if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png") {
					echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG dan GIF saja.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";
				}
				else{
					$uploaddir='../files/';
					$rnd=date(His);				
					$nama_file_upload=$rnd.'-'.$nama_photo;
					$alamatfile=$uploaddir.$nama_file_upload;
					
					if (move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
						$input=mysql_query("
							UPDATE tb_user SET 
							password 			= '$password', 
							nama_pengguna 		= '$nama_post', 
							file_name_foto 		= '$nama_file_upload'
							WHERE username 		= '$username_session'
						");
							
						if ($input) {
							echo "<script> alert('Edit data BERHASIL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=profile'>";	
						}
						else {
							echo "<script> alert('Edit data GAGAL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";	
						}
					}
					else{
						echo "<script> alert('Proses upload gagal, kode error = " . $_FILES['location']['error'].".') </script>";
						echo "<meta http-equiv='refresh' content='0; url=?page=edit_profile'>";
					}
				}
			}
			//batas jika foto diinput============
		}
	}
	//jika username diganti===========

?>