<?php

	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	
	include '../conn/koneksi.php';
	$query_user  = "SELECT * FROM tb_user WHERE username = '$username_session'";
	$sql_user    = mysql_query($query_user);
	$data_user   = mysql_fetch_array($sql_user);
	$total_user  = mysql_num_rows($sql_user);

	$username 		= $data_user['username'];
	$password 		= $data_user['password'];
	$nama_pengguna	= $data_user['nama_pengguna'];
	$hak_akses 		= $data_user['hak_akses'];
	$file_name_foto = $data_user['file_name_foto'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">PROFILE</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_profile" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputEmail1">Username</label>
              <input type="text" class="form-control" name="username" id="" value="<?php echo $username; ?>" placeholder="Username" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Password</label>
              <input type="text" class="form-control" name="password" id="" value="<?php echo $password; ?>" placeholder="Password" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Nama</label>
              <input type="text" class="form-control" name="nama_pengguna" id="" value="<?php echo $nama_pengguna; ?>" placeholder="Nama Lengkap" required="required">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Foto Sekarang</label>
              <br>
              <img src="../files/<?php echo $file_name_foto; ?>" style="width: auto; height: 150px;" alt="User Image">
            </div>
            <div class="form-group">
              <label for="exampleInputFile">Ganti Foto</label>
              <input type="file" name="file" id="exampleInputFile">
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=profile" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->

  </div>
</section>