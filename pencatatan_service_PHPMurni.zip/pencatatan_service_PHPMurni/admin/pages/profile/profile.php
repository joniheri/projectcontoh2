<?php

	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	
	include '../conn/koneksi.php';
	$query_user  = "SELECT * FROM tb_user WHERE username = '$username_session'";
	$sql_user    = mysql_query($query_user);
	$data_user   = mysql_fetch_array($sql_user);
	$total_user  = mysql_num_rows($sql_user);

	$username 		   = $data_user['username'];
	$password        = $data_user['password'];
	$nama_pengguna   = $data_user['nama_pengguna'];
	$hak_akses       = $data_user['hak_akses'];
	$file_name_foto  = $data_user['file_name_foto'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">PROFILE</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">

      <div class="col-md-3">

          <!-- Profile Image -->
          <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="../files/<?php echo $file_name_foto; ?>" alt="Foto Profile">
              <h3 class="profile-username text-center"><?php echo $nama_pengguna; ?></h3>
              <p class="text-muted text-center"><?php echo $hak_akses; ?></p>
              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Username</b> <a class="pull-right"><?php echo $username; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Password</b> <a class="pull-right"><?php echo $password; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Nama</b> <a class="pull-right"><?php echo $nama_pengguna; ?></a>
                </li>
                <li class="list-group-item">
                  <b>Hak Akses</b> <a class="pull-right"><?php echo $hak_akses; ?></a>
                </li>
              </ul>
              <a href="?page=edit_profile" class="btn btn-primary btn-block">Edit</a>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->

        </div>
        <!-- /.col -->

    </div>
    <!-- /.box-body -->
  </div>
</section>