<?php

	$no_surat_get = $_GET['no_surat_kirim'];

	include '../conn/koneksi.php';

	$query          = "SELECT * FROM tb_surat_masuk WHERE no_surat='$no_surat_get'";
	$sql            = mysql_query($query);
	$data           = mysql_fetch_array($sql);
	$no_surat           = $data['no_surat'];
	$index_surat        = $data['index_surat'];
	$kode_klasifikasi   = $data['kode_klasifikasi'];
	$dari               = $data['dari'];
	$isi_ringkasan      = $data['isi_ringkasan'];
	$tgl_masuk          = $data['tgl_masuk'];
	$keterangan         = $data['keterangan'];

	$index_surat_post		= $_POST['index_surat'];
	$kode_klasifikasi_post	= $_POST['kode_klasifikasi'];
	$no_surat_post			= $index_surat_post."/".$kode_klasifikasi_post;
	$dari_post 				= $_POST['dari'];
	$isi_ringkas_post 		= $_POST['isi_ringkas'];
	$tgl_masuk_post 		= $_POST['tgl_masuk'];
	$keterangan_post 		= $_POST['keterangan'];
	$file_post				= $_POST['file'];

	$nama_photo = $_FILES['file']['name'];
	$type 		= $_FILES['file']['type'];
	$ukuran 	= $_FILES['file']['size'];

	/*
	echo 'No Surat : '.$no_surat_get
	.'<br> Index Surat : '.$index_surat
	.'<br> Kode Klasifikasi : '.$kode_klasifikasi
	;
	*/

	//jika index atau kode klasifikasi ADA YANG SAMA
	if($index_surat == $index_surat_post && $kode_klasifikasi == $kode_klasifikasi_post){
		/*
		echo 
		'Ada yang sama'
		.'<br> Index Surat DB : '.$index_surat.' = Index Surat Post : '.$index_surat_post
		.'<br>atau <br> Kode Klasifikasi DB : '.$kode_klasifikasi.' = Kode Klasifikasi Post : '.$kode_klasifikasi_post
		;
		*/

		//jika file tidak diinput
		if ($nama_photo == ''){
			/*
			echo 
			'Index : '.$index_surat_post
			.'<br> Kode Klasifikasi : '.$kode_klasifikasi_post
			.'<br> No Surat : '.$no_surat_post
			.'<br> Dari : '.$dari_post
			.'<br> Isi Ringkasan : '.$isi_ringkas_post
			.'<br> Tgl Masuk : '.$tgl_masuk_post
			.'<br> Keterangan : '.$keterangan_post
			;
			*/
			$input=mysql_query("
				UPDATE tb_surat_masuk
				SET
				index_surat 		= '$index_surat_post',
				kode_klasifikasi 	= '$kode_klasifikasi_post', 
				dari 				= '$dari_post', 
				isi_ringkasan 		= '$isi_ringkas_post', 
				tgl_masuk 			= '$tgl_masuk_post', 
				keterangan 			= '$keterangan_post'
				WHERE no_surat = '$no_surat_get'
			");
				
			if ($input) {
				echo "<script> alert('Edit data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=surat_masuk'>";	
			}
			else {
				echo "<script> alert('Menambah data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";	
			}
		}
		//batas jika file tidak diinput=============

		//jika file diinput
		else if($nama_photo != ''){
			if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png" && $type != "application/pdf") {
				echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG dan PDF saja.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";
			}
			else{
				if($ukuran>1000000){
					echo "<script> alert('File Yang Di izinkan Hanya berukuran kurang dari 1MB.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";
				}
				else{
					$uploaddir='../files/';
					$rnd=date(His);				
					$nama_file_upload=$rnd.'-'.$nama_photo;
					$alamatfile=$uploaddir.$nama_file_upload;

					if(move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
						$input=mysql_query("
							UPDATE tb_surat_masuk
							SET
							index_surat 		= '$index_surat_post',
							kode_klasifikasi 	= '$kode_klasifikasi_post', 
							dari 				= '$dari_post', 
							isi_ringkasan 		= '$isi_ringkas_post', 
							tgl_masuk 			= '$tgl_masuk_post', 
							keterangan 			= '$keterangan_post',
							file 				= '$nama_file_upload'
							WHERE no_surat = '$no_surat_get'
						");
						if ($input) {
							echo "<script> alert('Edit data BERHASIL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=surat_masuk'>";	
						}
						else {
							echo "<script> alert('Menambah data GAGAL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_masuk'>";	
						}
					}
				}
			}
		}
		//batas jika file diinput
	}
	//batas jika ada index atau kode klasifikasi ADA YANG SAMA============

	//jika ada index atau kode klasifikasi TIDAK SAMA
	else{
		/*
		echo 
		'Tidak sama'
		.'<br> Index Surat DB : '.$index_surat.' = Index Surat Post : '.$index_surat_post
		.'<br>atau <br> Kode Klasifikasi DB : '.$kode_klasifikasi.' = Kode Klasifikasi Post : '.$kode_klasifikasi_post
		;
		*/
		$query_kode_surat=mysql_query("SELECT * FROM tb_surat_masuk where no_surat='$no_surat_post'");
		$cek=mysql_num_rows($query_kode_surat);
		if ($cek>0) {
			echo "<script> alert('Maaf, No Surat : $no_surat_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";
		}
		else{

			//jika file tidak diinput
			if ($nama_photo == ''){
				/*
				echo 
				'Index : '.$index_surat_post
				.'<br> Kode Klasifikasi : '.$kode_klasifikasi_post
				.'<br> No Surat : '.$no_surat_post
				.'<br> Dari : '.$dari_post
				.'<br> Isi Ringkasan : '.$isi_ringkas_post
				.'<br> Tgl Masuk : '.$tgl_masuk_post
				.'<br> Keterangan : '.$keterangan_post
				;
				*/
				$input=mysql_query("
					UPDATE tb_surat_masuk
					SET
					no_surat 			= '$no_surat_post',
					index_surat 		= '$index_surat_post',
					kode_klasifikasi 	= '$kode_klasifikasi_post', 
					dari 				= '$dari_post', 
					isi_ringkasan 		= '$isi_ringkas_post', 
					tgl_masuk 			= '$tgl_masuk_post', 
					keterangan 			= '$keterangan_post'
					WHERE no_surat = '$no_surat_get'
				");
					
				if ($input) {
					echo "<script> alert('Edit data BERHASIL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=surat_masuk'>";	
				}
				else {
					echo "<script> alert('Menambah data GAGAL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";	
				}
			}
			//batas jika file tidak diinput=============

			//jika file diinput
			else if($nama_photo != ''){
				if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png" && $type != "application/pdf") {
					echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG dan PDF saja.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";
				}
				else{
					if($ukuran>1000000){
						echo "<script> alert('File Yang Di izinkan Hanya berukuran kurang dari 1MB.') </script>";
						echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_masuk&no_surat_kirim=$no_surat_get'>";
					}
					else{
						$uploaddir='../files/';
						$rnd=date(His);				
						$nama_file_upload=$rnd.'-'.$nama_photo;
						$alamatfile=$uploaddir.$nama_file_upload;

						if(move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
							$input=mysql_query("
								UPDATE tb_surat_masuk
								SET
								no_surat 			= '$no_surat_post',
								index_surat 		= '$index_surat_post',
								kode_klasifikasi 	= '$kode_klasifikasi_post', 
								dari 				= '$dari_post', 
								isi_ringkasan 		= '$isi_ringkas_post', 
								tgl_masuk 			= '$tgl_masuk_post', 
								keterangan 			= '$keterangan_post',
								file 				= '$nama_file_upload'
								WHERE no_surat = '$no_surat_get'
							");
							if ($input) {
								echo "<script> alert('Edit data BERHASIL.') </script>";
								echo "<meta http-equiv='refresh' content='0; url=?page=surat_masuk'>";	
							}
							else {
								echo "<script> alert('Menambah data GAGAL.') </script>";
								echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_masuk'>";	
							}
						}
					}
				}
			}
			//batas jika file diinput
		}
	}
	//batas jika ada index atau kode klasifikasi TIDAK SAMA============

?>