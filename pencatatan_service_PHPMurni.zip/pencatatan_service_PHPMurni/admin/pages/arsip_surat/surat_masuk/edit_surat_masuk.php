<?php
  include '../conn/koneksi.php';

  $no_surat_get = $_GET['no_surat_kirim'];

  $query          = "SELECT * FROM tb_surat_masuk WHERE no_surat='$no_surat_get'";
  $sql            = mysql_query($query);
  $data           = mysql_fetch_array($sql);
  $no_surat           = $data['no_surat'];
  $index_surat        = $data['index_surat'];
  $kode_klasifikasi   = $data['kode_klasifikasi'];
  $dari               = $data['dari'];
  $isi_ringkasan      = $data['isi_ringkasan'];
  $tgl_masuk          = $data['tgl_masuk'];
  $keterangan         = $data['keterangan'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM EDIT SURAT MASUK</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_surat_masuk&no_surat_kirim=<?php echo $no_surat_get; ?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Index</label>
              <input type="text" class="form-control" name="index_surat" id="" value="<?php echo $index_surat; ?>" placeholder="Index" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Kode Klasifikasi</label>
              <input type="text" class="form-control" name="kode_klasifikasi" id="" value="<?php echo $kode_klasifikasi; ?>" placeholder="Kode Klasifikasi" required>
            </div>
            <!--
            <div class="form-group">
              <label for="exampleInputEmail1">No Surat</label>
              <input type="text" class="form-control" name="no_surat" id="" value="<?php echo $no_surat_get;?>" placeholder="No Surat" required>
            </div>
            -->
            <div class="form-group">
              <label for="exampleInputPassword1">Dari</label>
              <input type="text" class="form-control" name="dari" id="" value="<?php echo $dari; ?>" placeholder="dari" required>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Ganti File Surat (type file : JPG, JPEG, PNG, GIF dan PDF saja)</label>
              <input type="file" name="file" id="exampleInputFile">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Isi Ringkas</label>
              <textarea class="form-control" rows="3" name="isi_ringkas" placeholder="Isi ringkasan"><?php echo $isi_ringkasan; ?></textarea>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Tanggal Masuk</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input type="text" class="form-control" name="tgl_masuk" value="<?php echo $tgl_masuk; ?>" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
              </div>
            </div>
            <div class="form-group">
              <label for="">Keterangan</label>
              <textarea class="form-control" rows="3" name="keterangan" placeholder="Keterangan ..."><?php echo $keterangan;?></textarea>
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_data_pengguna" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=surat_masuk" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>