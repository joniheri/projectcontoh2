<?php
	include '../conn/koneksi.php';

	$no_surat_get = $_GET['no_surat_kirim'];

	$query 	= mysql_query("DELETE FROM tb_surat_keluar WHERE no_surat='$no_surat_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";
	}
?>