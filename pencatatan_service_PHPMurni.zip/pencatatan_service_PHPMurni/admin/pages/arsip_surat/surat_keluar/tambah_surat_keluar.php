<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM TAMBAH SURAT KELUAR</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_surat_keluar" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Index</label>
              <input type="text" class="form-control" name="index_surat" id="" placeholder="Index" required>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Kode Klasifikasi</label>
              <input type="text" class="form-control" name="kode_klasifikasi" id="" placeholder="Kode Klasifikasi" required>
            </div>
            <!--
            <div class="form-group">
              <label for="exampleInputEmail1">No Surat</label>
              <input type="text" class="form-control" name="no_surat" id="" placeholder="No Surat" required>
            </div>
            -->
            <div class="form-group">
              <label for="exampleInputPassword1">Tujuan</label>
              <input type="text" class="form-control" name="tujuan" id="" placeholder="Tujuan" required>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Upload File Surat (type file : JPG, JPEG, PNG, GIF dan PDF saja)</label>
              <input type="file" name="file" id="exampleInputFile">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Isi Ringkas</label>
              <textarea class="form-control" rows="3" name="isi_ringkas" placeholder="Isi ringkasan"></textarea>
            </div>
            <div class="form-group">
              <label for="exampleInputEmail1">Tanggal Keluar</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input type="text" class="form-control" name="tgl_keluar" data-inputmask="'alias': 'dd/mm/yyyy'" data-mask>
              </div>
            </div>
            <div class="form-group">
              <label for="">Keterangan</label>
              <textarea class="form-control" rows="3" name="keterangan" placeholder="Keterangan ..."></textarea>
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_data_pengguna" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=surat_keluar" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>