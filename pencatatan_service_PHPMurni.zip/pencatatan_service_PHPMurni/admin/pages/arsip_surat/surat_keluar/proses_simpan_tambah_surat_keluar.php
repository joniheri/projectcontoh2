<?php
	include '../conn/koneksi.php';
	
	$index_surat_post		= $_POST['index_surat'];
	$kode_klasifikasi_post	= $_POST['kode_klasifikasi'];
	$no_surat_post			= $index_surat_post."/".$kode_klasifikasi_post;
	$tujuan_post			= $_POST['tujuan'];
	$isi_ringkas_post 		= $_POST['isi_ringkas'];
	$tgl_keluar_post 		= $_POST['tgl_keluar'];
	$keterangan_post 		= $_POST['keterangan'];
	$file_post				= $_POST['file'];

	$nama_photo = $_FILES['file']['name'];
	$type 		= $_FILES['file']['type'];
	$ukuran 	= $_FILES['file']['size'];

	$query_no_surat=mysql_query("SELECT * FROM tb_surat_keluar where no_surat='$no_surat_post'");
	$cek=mysql_num_rows($query_no_surat);
	if ($cek>0) {
		echo "<script> alert('Maaf, No Surat : $no_surat_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_keluar'>";
	}
	else{
		//jika file tidak diinput
		if ($nama_photo == ''){
			/*
			echo 
			'Index : '.$index_surat_post
			.'<br> Kode Klasifikasi : '.$kode_klasifikasi_post
			.'<br> No Surat : '.$no_surat_post
			.'<br> Dari : '.$dari_post
			.'<br> Isi Ringkasan : '.$isi_ringkas_post
			.'<br> Tgl Masuk : '.$tgl_masuk_post
			.'<br> Keterangan : '.$keterangan_post
			;
			*/
			$input=mysql_query("
				INSERT INTO tb_surat_keluar
				(
				no_surat,
				index_surat,
				kode_klasifikasi, 
				tujuan, 
				isi_ringkasan, 
				tgl_keluar, 
				keterangan
				) 
				values
				(
				'$no_surat_post',
				'$index_surat_post',
				'$kode_klasifikasi_post',
				'$dari_post',
				'$isi_ringkas_post',
				'$tgl_keluar_post',
				'$keterangan_post'
				)
			");
				
			if ($input) {
				echo "<script> alert('Menambah data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";	
			}
			else {
				echo "<script> alert('Menambah data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_keluar'>";	
			}
		}
		//batas jika file tidak diinput=============

		//jika file diinput
		else if($nama_photo != ''){
			if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png" && $type != "application/pdf") {
				echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG, GIF dan PDF saja.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_keluar'>";
			}
			else{
				if($ukuran>1000000){
					echo "<script> alert('File Yang Di izinkan Hanya berukuran kurang dari 1MB.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_keluar'>";
				}
				else{
					$uploaddir='../files/';
					$rnd=date(His);				
					$nama_file_upload=$rnd.'-'.$nama_photo;
					$alamatfile=$uploaddir.$nama_file_upload;

					if(move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
						$input=mysql_query("
							INSERT INTO tb_surat_keluar
							(
							no_surat,
							index_surat,
							kode_klasifikasi, 
							tujuan, 
							isi_ringkasan, 
							tgl_keluar, 
							keterangan,
							file
							) 
							values
							(
							'$no_surat_post',
							'$index_surat_post',
							'$kode_klasifikasi_post',
							'$dari_post',
							'$isi_ringkas_post',
							'$tgl_keluar_post',
							'$keterangan_post',
							'$nama_file_upload'
							)
						");
						if ($input) {
							echo "<script> alert('Menambah data BERHASIL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";	
						}
						else {
							echo "<script> alert('Menambah data GAGAL, error_reporting.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=tambah_surat_keluar'>";	
						}
					}
				}
			}
		}
		//batas jika file diinput
	}

?>