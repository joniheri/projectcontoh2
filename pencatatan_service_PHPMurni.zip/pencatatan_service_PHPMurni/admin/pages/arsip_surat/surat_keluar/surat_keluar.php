<?php
  include '../conn/koneksi.php';

  $cari_post = $_POST['cari'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">SURAT KELUAR</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form action="?page=surat_keluar" method="post">
        <div class="box-header">
          <a style="margin-right: 5px;" href="?page=tambah_surat_keluar" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
          <div class="box-tools">
              <div class="input-group input-group-sm" style="width: 150px;">
                <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
                <div class="input-group-btn">
                  <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                </div>
              </div>
          </div>
        </div>
      </form>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr style="background-color: #7DB3D2; text-align: center; font-weight: bold;">
            <td>No</td>
            <td>No Surat</td>
            <td>Index</td>
            <td>Kode Klasifikasi</td>
            <td>Tujuan</td>
            <td>Isi Ringkas</td>
            <td>Tanggal Keluar</td>
            <td>Keterangan</td>
            <td style="width: 80px;">File</td>
            <td style="width: 150px;">Aksi</td>
          </tr>
          <?php
            $query  = "
              SELECT * FROM tb_surat_keluar 
              WHERE tujuan LIKE '%$cari_post%'
              OR isi_ringkasan LIKE '%$cari_post%'
              OR keterangan LIKE '%$cari_post%'
              ORDER by tgl_keluar DESC
            ";
            $sql    = mysql_query($query);
            $total  = mysql_num_rows($sql);
            $no     = 1;
            
            while ($data=mysql_fetch_array($sql)) {
              $file = $data['file'];
          ?>
          <tr>
            <td><?php echo $no; ?></td>
            <td><?php echo $data['no_surat']; ?></td>
            <td><?php echo $data['index']; ?></td>
            <td><?php echo $data['kode_klasifikasi']; ?></td>
            <td><?php echo $data['tujuan']; ?></td>
            <td><?php echo $data['isi_ringkasan']; ?></td>
            <td><?php echo $data['tgl_keluar']; ?></td>
            <td><?php echo $data['keterangan']; ?></td>
            <td>
              <?php
                $tampil_file;
                if($file == ''){
                  $tampil_file = 'Tidak ada';
                }
                else if($file != ''){
                  $tampil_file = "<a class='btn btn-success btn-default' style='color: #ffffff;' title='Lihat File' href='../files/$file' target='_blank'><i class='fa fa-eye'></i></a>";
                }
                echo $tampil_file;
              ?>
            </td>
            <td>
              <a class="btn btn-warning btn-default" style="color: #ffffff;" title="Edit" href="?page=edit_surat_keluar&no_surat_kirim=<?php echo $data['no_surat']; ?>"><i class="fa fa-pencil"></i></a>
              <a class="btn btn-danger  btn-default" style="color: #ffffff;" title="Hapus" href="?page=proses_hapus_surat_keluar&no_surat_kirim=<?php echo $data['no_surat']; ?>" onClick="return confirm('Yakin ingin menghapus data dengan No Surat : <?php echo $data['no_surat']; ?>...?');"><i class="fa fa-trash"></i></a>
            </td>
          </tr>
          <?php $no++; } ?>
        </table>
      </div>
    </div>
    <!-- /.box-body -->
  </div>
</section>