<?php
	
	$no_surat_get = $_GET['no_surat_kirim'];

	include '../conn/koneksi.php';
	
	$query          = "SELECT * FROM tb_surat_keluar WHERE no_surat='$no_surat_get'";
	$sql            = mysql_query($query);
	$data           = mysql_fetch_array($sql);
	$no_surat           = $data['no_surat'];
	$index_surat        = $data['index_surat'];
	$kode_klasifikasi   = $data['kode_klasifikasi'];

	$index_surat_post		= $_POST['index_surat'];
	$kode_klasifikasi_post	= $_POST['kode_klasifikasi'];
	$no_surat_post			= $index_surat_post."/".$kode_klasifikasi_post;
	$tujuan_post			= $_POST['tujuan'];
	$isi_ringkasan_post 	= $_POST['isi_ringkasan'];
	$tgl_keluar_post 		= $_POST['tgl_keluar'];
	$keterangan_post 		= $_POST['keterangan'];
	$file_post				= $_POST['file'];

	$nama_photo = $_FILES['file']['name'];
	$type 		= $_FILES['file']['type'];
	$ukuran 	= $_FILES['file']['size'];

	//jika index atau kode klasifikasi ADA YANG SAMA
	if($index_surat == $index_surat_post && $kode_klasifikasi == $kode_klasifikasi_post){
		/*
		echo 
		'Ada yang sama'
		.'<br> Index Surat DB : '.$index_surat.' = Index Surat Post : '.$index_surat_post
		.'<br>atau <br> Kode Klasifikasi DB : '.$kode_klasifikasi.' = Kode Klasifikasi Post : '.$kode_klasifikasi_post
		;
		*/

		//jika file tidak diinput
		if ($nama_photo == ''){
			/*
			echo 
			'Index : '.$index_surat_post
			.'<br> Kode Klasifikasi : '.$kode_klasifikasi_post
			.'<br> No Surat : '.$no_surat_post
			.'<br> Tujuan : '.$tujuan_post
			.'<br> Isi Ringkasan : '.$isi_ringkas_post
			.'<br> Tgl Keluar : '.$tgl_keluar_post
			.'<br> Keterangan : '.$keterangan_post
			;
			*/
			$input=mysql_query("
				UPDATE tb_surat_keluar
				SET 
				tujuan 				= '$tujuan_post', 
				isi_ringkasan 		= '$isi_ringkasan_post', 
				tgl_keluar 			= '$tgl_keluar_post', 
				keterangan 			= '$keterangan_post'
				WHERE no_surat = '$no_surat_get'
			");
				
			if ($input) {
				echo "<script> alert('Edit data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";	
			}
			else {
				echo "<script> alert('Edit data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";	
			}
		}
		//batas jika file tidak diinput===============

		//jika file diinput
		else if($nama_photo != ''){
			if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png" && $type != "application/pdf") {
				echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG dan PDF saja.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";
			}
			else{
				if($ukuran>1000000){
					echo "<script> alert('File Yang Di izinkan Hanya berukuran kurang dari 1MB.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";
				}
				else{
					$uploaddir='../files/';
					$rnd=date(His);				
					$nama_file_upload=$rnd.'-'.$nama_photo;
					$alamatfile=$uploaddir.$nama_file_upload;

					if(move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
						$input=mysql_query("
							UPDATE tb_surat_keluar
							SET
							tujuan 				= '$tujuan_post', 
							isi_ringkasan 		= '$isi_ringkasan_post', 
							tgl_keluar 			= '$tgl_keluar_post', 
							keterangan 			= '$keterangan_post',
							file 				= '$nama_file_upload'
							WHERE no_surat = '$no_surat_get'
						");
							
						if ($input) {
							echo "<script> alert('Edit data BERHASIL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";	
						}
						else {
							echo "<script> alert('Edit data GAGAL.') </script>";
							echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";	
						}
					}
				}
			}
		}
		//batas jika file diinput===============
	}
	//batas jika index atau kode klasifikasi ADA YANG SAMA

	//jika ada index atau kode klasifikasi TIDAK SAMA
	else{
		$query_kode_surat=mysql_query("SELECT * FROM tb_surat_keluar where no_surat='$no_surat_post'");
		$cek=mysql_num_rows($query_kode_surat);
		if ($cek>0) {
			echo "<script> alert('Maaf, No Surat : $no_surat_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";
		}
		else{

			//jika file tidak diinput
			if ($nama_photo == ''){
				/*
				echo 
				'Index : '.$index_surat_post
				.'<br> Kode Klasifikasi : '.$kode_klasifikasi_post
				.'<br> No Surat : '.$no_surat_post
				.'<br> Tujuan : '.$tujuan_post
				.'<br> Isi Ringkasan : '.$isi_ringkas_post
				.'<br> Tgl Keluar : '.$tgl_keluar_post
				.'<br> Keterangan : '.$keterangan_post
				;
				*/
				$input=mysql_query("
					UPDATE tb_surat_keluar
					SET 
					index_surat			= '$index_surat_post', 
					kode_klasifikasi	= '$kode_klasifikasi_post', 
					no_surat			= '$no_surat_post', 
					tujuan 				= '$tujuan_post', 
					isi_ringkasan 		= '$isi_ringkasan_post', 
					tgl_keluar 			= '$tgl_keluar_post', 
					keterangan 			= '$keterangan_post'
					WHERE no_surat = '$no_surat_get'
				");
					
				if ($input) {
					echo "<script> alert('Edit data BERHASIL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";	
				}
				else {
					echo "<script> alert('Edit data GAGAL.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";	
				}
			}
			//batas jika file tidak diinput===============

			//jika file diinput
			else if($nama_photo != ''){
				if ($type != "image/gif"  &&  $type != "image/jpg"  && $type != "image/jpeg" && $type != "image/png" && $type != "application/pdf") {
					echo "<script> alert('File Yang Di izinkan Hanya JPG, JPEG, PNG dan PDF saja.') </script>";
					echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";
				}
				else{
					if($ukuran>1000000){
						echo "<script> alert('File Yang Di izinkan Hanya berukuran kurang dari 1MB.') </script>";
						echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";
					}
					else{
						$uploaddir='../files/';
						$rnd=date(His);				
						$nama_file_upload=$rnd.'-'.$nama_photo;
						$alamatfile=$uploaddir.$nama_file_upload;

						if(move_uploaded_file($_FILES['file']['tmp_name'],$alamatfile)){
							$input=mysql_query("
								UPDATE tb_surat_keluar
								SET
								index_surat			= '$index_surat_post', 
								kode_klasifikasi	= '$kode_klasifikasi_post', 
								no_surat			= '$no_surat_post', 
								tujuan 				= '$tujuan_post', 
								isi_ringkasan 		= '$isi_ringkasan_post', 
								tgl_keluar 			= '$tgl_keluar_post', 
								keterangan 			= '$keterangan_post',
								file 				= '$nama_file_upload'
								WHERE no_surat = '$no_surat_get'
							");
								
							if ($input) {
								echo "<script> alert('Edit data BERHASIL.') </script>";
								echo "<meta http-equiv='refresh' content='0; url=?page=surat_keluar'>";	
							}
							else {
								echo "<script> alert('Edit data GAGAL.') </script>";
								echo "<meta http-equiv='refresh' content='0; url=?page=edit_surat_keluar&no_surat_kirim=$no_surat_get'>";	
							}
						}
					}
				}
			}
			//batas jika file diinput===============
		}
	}
	//batas jika ada index atau kode klasifikasi TIDAK SAMA===============

?>