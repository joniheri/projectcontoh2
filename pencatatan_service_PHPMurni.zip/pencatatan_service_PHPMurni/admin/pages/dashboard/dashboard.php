<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
		DASKBOARD 
	</h1>
	<ol class="breadcrumb">
		<li class="active">Dashboard</li>
	</ol>
</section>
<!-- end Content Header (Page header) -->

<!-- isi konten -->
<section class="content">

  <!-- Default box -->
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">Halaman Dashboard</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
          <i class="fa fa-minus"></i>
        </button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i>
        </button>
      </div>

    </div>

    <!-- box-body -->
    <div class="box-body">
      <div class="col-md-4">
        <img style="height: auto; width: 350px;" src="../img/kantor1.jpeg">
      </div>      
      <div class="col-md-8">
        <p>
          E-Document (Electronic Document) adalah suatu konten elektronik yang berupa program atau file komputer yang membutuhkan media elektronik atau teknologi elektronik display untuk bisa menggunakan, membaca atau melihatnya.
        </p>
        <p>
          Terciptanya suatu E-Dokument tidak terlalu rumit, dokument asli, kertas atau hard document dijadikan file komputer dengan cara scanning kemudian data ini dipilih mana yang penting atau kurang penting klasifikasi ini disebut sistem verification, selanjutnya dilakukan proses index, yaitu pengelompokan daftar isi yang bertujuan untuk memudahkan pencarian data. Dalam indexing dilakukan kategorisasi berupa tipe dokument, tanggal, nama pembuat serta kata kunci. Sistem indexing bisa dilakukan dengan metode manual atau otomatis.
        </p>
        <p>
          Adapun kelebihan E-Dokument dibandingkan dokument biasa adalah : Paperless (ramah lingkungan) E-Dokument tidak menggunakan kertas dengan demikian penghematan kertas terjadi yang mana kertas juga berasal dari sumber daya alam. Penghematan waktu dengan adanya E-Dokument untuk mencari suatu informasi yang ada dalam sebuah dokument bisa lebih cepat. E-Dokument lebih mudah disebarkan atau dibagikan. Selain itu E-Dokument lebih aman disimpan dengan menggunakan metode elektronik signature.
        </p>
      </div>
    </div>
    <!-- end box-body -->

    <div class="box-footer">
      Footer
    </div>
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->

</section>
<!-- end isi konten -->