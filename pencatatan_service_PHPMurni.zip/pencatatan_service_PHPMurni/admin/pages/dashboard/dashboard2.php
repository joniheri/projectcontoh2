<?php
  include '../conn/koneksi.php';
?>

<!-- Content Header (Page header) -->
<section class="content-header">
	<h1>
		DASHBOARD 
	</h1>
	<ol class="breadcrumb">
		<li class="active">Dashboard</li>
	</ol>
</section>
<!-- end Content Header (Page header) -->

<!-- isi konten -->
<section class="content">

  <!-- Default box -->
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">CV. BASIS COMPUTER</h3>

      <div class="box-tools pull-right">
        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
          <i class="fa fa-minus"></i>
        </button>
        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
          <i class="fa fa-times"></i>
        </button>
      </div>

    </div>

    <!-- box-body -->
    <div class="box-body">

      <!-- surat masuk -->
      <?php
        $query_konsumen  = "SELECT * FROM tbkonsumen";
        $sql_konsumen    = mysql_query($query_konsumen);
        $total_konsumen  = mysql_num_rows($sql_konsumen);
        $no_konsumen     = 0;
        
        while ($data_konsumen=mysql_fetch_array($sql_konsumen)) {
          $no_konsumen++; 
        }
      ?>
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-primary">
          <div class="inner">
            <h3><?php echo $no_konsumen; ?></h3>
            <p>Konsumen</p>
          </div>
          <div class="icon">
            <i class="glyphicon glyphicon-envelope"></i>
          </div>
          <a href="?page=data_konsumen" class="small-box-footer">Lihat Detail <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- end surat masuk -->

      <!-- surat keluar -->
      <?php
        $query_surat_keluar  = "SELECT * FROM tbkerusakan";
        $sql_surat_keluar    = mysql_query($query_surat_keluar);
        $total_surat_keluar  = mysql_num_rows($sql_surat_keluar);
        $no_kerusakan     = 0;
        
        while ($data_surat_keluar=mysql_fetch_array($sql_surat_keluar)) {
          $no_kerusakan++; 
        }
      ?>
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-green">
          <div class="inner">
            <h3><?php echo $no_kerusakan; ?></h3>
            <p>Kerusakan</p>
          </div>
          <div class="icon">
            <i class="glyphicon glyphicon-envelope"></i>
          </div>
          <a href="?page=data_kerusakan" class="small-box-footer">Lihat Detail <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- end surat keluar -->

      <!-- ajuan surat -->   
      <?php
        $query_ajuan_surat  = "SELECT * FROM tbsparepart";
        $sql_ajuan_surat    = mysql_query($query_ajuan_surat);
        $total_ajuan_surat  = mysql_num_rows($sql_ajuan_surat);
        $no_sparepart     = 0;
        
        while ($data_ajuan_surat=mysql_fetch_array($sql_ajuan_surat)) {
          $no_sparepart++; 
        }
      ?>   
      <div class="col-lg-3 col-xs-6">
        <!-- small box -->
        <div class="small-box bg-yellow">
          <div class="inner">
            <h3><?php echo $no_sparepart; ?></h3>
            <p>Sparepart</p>
          </div>
          <div class="icon">
            <i class="glyphicon glyphicon-envelope"></i>
          </div>
          <a href="?page=data_sparepart" class="small-box-footer">Lihat Detail <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <!-- end ajuan surat -->

    </div>
    <!-- end box-body -->

    <div class="box-footer">
      Footer
    </div>
    <!-- /.box-footer-->
  </div>
  <!-- /.box -->

</section>
<!-- end isi konten -->