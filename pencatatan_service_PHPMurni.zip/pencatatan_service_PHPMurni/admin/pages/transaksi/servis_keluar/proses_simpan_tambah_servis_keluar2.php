<?php
	include '../conn/koneksi.php';

	$id_keluar_post 		= $_POST['id_keluar'];
	$no_servis_post 		= $_POST['no_servis'];
	$tgl_keluar_post 		= date('Y-m-d');


	// echo "$id_keluar_post, $no_servis_post, $tgl_keluar_post";
	
	$query_id_keluar=mysql_query("SELECT * FROM tbskeluar where id_keluar='$id_keluar_post'");
	$cek=mysql_num_rows($query_id_keluar);
	if ($cek>0) {
		echo "<script> alert('Maaf, Id Keluar : $id_keluar_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_keluar2'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbskeluar
			(
			id_keluar,
			no_servis, 
			tgl_keluar
			) 
			values
			(
			'$id_keluar_post',
			'$no_servis_post',
			'$tgl_keluar_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_sp_servis_keluar'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_keluar2'>";	
		}
	}
	
?>