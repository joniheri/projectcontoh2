<?php
  include '../conn/koneksi.php';

  $id_klr_get = $_GET['id_klr_kirim'];

  $query           = "SELECT * FROM tbskeluar WHERE id_keluar='$id_klr_get'";
  $sql             = mysql_query($query);
  $data            = mysql_fetch_array($sql);
  $id_keluar       = $data['id_keluar'];
  $no_servis       = $data['no_servis'];
  $id_teknisi      = $data['id_teknisi'];
  $tgl_masuk       = $data['tgl_masuk'];
  $nama_barang     = $data['nama_barang'];
  $jenis_barang    = $data['jenis_barang'];
  $desc_kerusakan  = $data['desc_kerusakan'];
  $kelengkapan     = $data['kelengkapan'];
  $status          = $data['status'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM TAMBAH SPAREPART DAN KERUSAKAN SERVICE MASUK</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_sp_servis_keluar2&id_klr_kirim=<?php echo $id_klr_get;?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">

            <input type="hidden" class="form-control" name="id_keluar" value="<?php echo $id_keluar; ?>" id="" placeholder="" required="required">

            <div class="form-group">
              <label for="exampleInputPassword1">No Servis</label>
              <input type="text" class="form-control" disabled="disabled" name="no_servis" value="<?php echo $no_servis; ?>" id="" placeholder="" required="required">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Id Teknisi</label>
              <input type="text" class="form-control" name="id_teknisi" value="<?php echo $id_teknisi; ?>" id="" placeholder="" required="required">
            </div>
          </div>
            <!-- rusak -->
            <div class="col-md-6">
            <!-- tombol tambah -->
            <form method="post" action="?page=servis_keluar">
            <div class="box-header">
              <a style="margin-right: 5px;" href="?page=tambah_servis_keluar2" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
              <div class="box-tools">
                <div class="input-group input-group-sm" style="width: 150px;">
                  <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
                  <div class="input-group-btn">
                    <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                  </div>
                </div>
              </div>
            </div>
            </form>
            <!--end tombol tambah  -->
            <div class="box-body table-responsive no-padding">
            <table class="table table-hover">
                <tr style="background-color: #7DB3D2;">
                  <th width="120">ID Sparepart</th>
                  <th>Nama Sparepart</th>
                  <th width="120">Jenis Sparepart</th>
                  <th width="100">Harga</th>
                  <th width="100">Aksi</th>
                </tr>
                <?php
                ?>
            </table>
            </div>
            </div>
          <!-- end rusak -->
          <!-- sparepart -->
          <div class="col-md-6">
          <!-- tombol tambah -->
          <form method="post" action="?page=servis_keluar">
          <div class="box-header">
            <a style="margin-right: 5px;" href="?page=tambah_servis_keluar2" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
            <div class="box-tools">
              <div class="input-group input-group-sm" style="width: 150px;">
                <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
                <div class="input-group-btn">
                  <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
                </div>
              </div>
            </div>
          </div>
          </form>
          <!-- end tombol tambah -->
          <div class="box-body table-responsive no-padding">
          <table class="table table-hover">
              <tr style="background-color: #7DB3D2;">
                <th width="120">ID Sparepart</th>
                <th>Nama Sparepart</th>
                <th width="120">Jenis Sparepart</th>
                <th width="100">Harga</th>
                <th width="100">Aksi</th>
              </tr>
              <?php
               ?>
          </table>
          </div>
        </div>
        <!-- end sparepart -->
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=servis_masuk" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>