<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM SERVICE KELUAR</h3>
    </div>
<?php 
  include '../conn/koneksi.php';
  include '../conn/autoid.php';

?>
    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_servis_keluar" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <!-- autono masuk -->
              <input type="hidden" class="form-control" name="id_keluar" value="<?= $auto_idk ?>" id="" placeholder="" >
            <!-- end autono masuk -->
            <div class="form-group">
              <label for="exampleInputPassword1">No Servis - Nama Konsumen - Nama Barang</label>
              <select name="no_servis" class="form-control select2" style="width: 100%;">
                <?php
                  $query  = "SELECT * FROM v_smasuk";
                  $sql    = mysql_query($query);
                  $total  = mysql_num_rows($sql);
                  $no     = 1;
                  
                  while ($data=mysql_fetch_array($sql)) {
                ?>
                <option value="<?php echo $data['no_servis'] ?>"><?php echo $data['no_servis'].' - '.$data['nama'].' - '.$data['nama_barang'] ?></option>
                <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Nama Teknisi</label>
              <select name="id_teknisi" class="form-control select2" style="width: 100%;">
                <?php
                  $query  = "SELECT * FROM tbteknisi";
                  $sql    = mysql_query($query);
                  $total  = mysql_num_rows($sql);
                  $no     = 1;
                  
                  while ($data=mysql_fetch_array($sql)) {
                ?>
                <option value="<?php echo $data['id_teknisi'] ?>"><?php echo $data['nama_teknisi'] ?></option>
                <?php
                  }
                ?>
              </select>
            </div>
             <div class="form-group">
              <label for="exampleInputEmail1">Tgl Keluar</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input type="text" class="form-control" name="tgl_keluar" data-inputmask="'alias': 'yyyy-mm-dd'" data-mask>
              </div>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Servis</label>
              <select name="id_kerusakan" class="form-control select2" style="width: 100%;">
                <?php
                  $query  = "SELECT * FROM tbkerusakan";
                  $sql    = mysql_query($query);
                  $total  = mysql_num_rows($sql);
                  $no     = 1;
                  
                  while ($data=mysql_fetch_array($sql)) {
                ?>
                <option value="<?php echo $data['id_kerusakan'] ?>"><?php echo $data['nama_kerusakan'] ?></option>
                <?php
                  }
                ?>
              </select>
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Nama Sparepart</label>
              <select name="id_sp" class="form-control select2" style="width: 100%;">
                <?php
                  $query  = "SELECT * FROM tbsparepart";
                  $sql    = mysql_query($query);
                  $total  = mysql_num_rows($sql);
                  $no     = 1;
                  
                  while ($data=mysql_fetch_array($sql)) {
                ?>
                <option value="<?php echo $data['id_sp'] ?>"><?php echo $data['nama_sp'] ?></option>
                <?php
                  }
                ?>
              </select>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Biaya Tambahan</label>
              <input type="text" class="form-control" name="biaya_tambahan" id="" placeholder="Biaya Tambahan">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Total</label>
              <input type="text" class="form-control" name="total" id="" placeholder="Total" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_servis_keluar" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=servis_keluar" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>