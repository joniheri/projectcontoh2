<?php
	include '../conn/koneksi.php';

	$id_klr_get = $_GET['id_klr_get'];

	//echo $id_tek_get;

	
	$query 	= mysql_query("DELETE FROM tbskeluar WHERE id_keluar='$id_klr_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_keluar'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_keluar'>";
	}
	
?>