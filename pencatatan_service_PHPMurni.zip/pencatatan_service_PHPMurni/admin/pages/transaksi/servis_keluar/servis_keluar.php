<?php
  include '../conn/koneksi.php';

  $cari_post = $_POST['cari'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">DATA SERVICE KELUAR</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body no-padding">
      <form method="post" action="?page=servis_keluar">
        <div class="box-header">
          <!--
          <a style="margin-right: 5px;" href="?page=tambah_servis_keluar2" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
          -->
          <br>
          <div class="box-tools">
            <div class="input-group input-group-sm" style="width: 150px;">
              <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </div>
        </div>
      </form>
      <!-- /.box-header -->

      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr style="background-color: #222D32; color: #C9CCCD;">
            <th width="100" style="vertical-align: middle; text-align: center;">No Servis</th>
            <th width="120" style="vertical-align: middle; text-align: center;">Nama Konsumen</th>
            <th width="120" style="vertical-align: middle; text-align: center;">Nama Barang</th>
            <th width="100" style="vertical-align: middle; text-align: center;">Tgl Masuk</th>
            <th width="100" style="vertical-align: middle; text-align: center;">Tgl Keluar</th>
            <th width="120" style="vertical-align: middle; text-align: center;">Keluhan</th>
            <th width="30" style="vertical-align: middle; text-align: center;">Aksi</th>
          </tr>
          <?php
            $query  = "SELECT tbservis.*, 
                      tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
                      FROM tbservis
                      INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen)
                      WHERE status ='Telah Diambil'
                      ORDER BY no_servis ASC
            ";
            $sql    = mysql_query($query);
            $total  = mysql_num_rows($sql);
            $no     = 1;
            
            while ($data=mysql_fetch_array($sql)) {
              $file = $data['file'];
          ?>
          <tr>
            <td><?php echo $data['no_servis']; ?></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['nama_barang']; ?></td>
            <td><?php echo $data['tgl_masuk']; ?></td>
            <td><?php echo $data['tgl_keluar']; ?></td>
            <td><?php echo $data['desc_kerusakan']; ?></td>
            <td style="vertical-align: middle; text-align: center;"> 
              <div class="btn-group">
                <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" style="min-width: 30px;">
                  <i class="glyphicon glyphicon-menu-hamburger"></i>
                </button>
                <ul class="dropdown-menu pull-right" role="menu">
                  <li><a href="?page=button_cetak_servis_masuk&no_srv_kirim=<?php echo $data['no_servis']; ?>"><i class='fa fa-print'></i>Print</a></li>
                  <li><a href="?page=edit_servis_masuk&no_srv_kirim=<?php echo $data['no_servis']; ?>"><i class='fa fa-pencil'></i>Edit</a></li>
                </ul>
              </div>
            </td>
          </tr>
          <?php $no++; } ?>
        </table>
      </div>
    </div>
    <!-- /.box-body -->
  </div>
</section>