<?php
	include '../conn/koneksi.php';

	$id_keluar_post 		= $_POST['id_keluar'];
	$no_servis_post 		= $_POST['no_servis'];
	$id_teknisi_post 		= $_POST['id_teknisi'];
	$tgl_keluar_post 		= $_POST['tgl_keluar'];
	$id_kerusakan_post 		= $_POST['id_kerusakan'];
	$id_sp_post 			= $_POST['id_sp'];
	$biaya_tambahan_post 	= $_POST['biaya_tambahan'];
	$total_post 			= $_POST['total'];

	//echo "$id_keluar_post, $no_servis_post, $id_teknisi_post, $tgl_keluar_post, $id_kerusakan_post, $id_sp_post, $biaya_tambahan_post, $total_post";
	
	$query_id_keluar=mysql_query("SELECT * FROM tbskeluar where id_keluar='$id_keluar_post'");
	$cek=mysql_num_rows($query_id_keluar);
	if ($cek>0) {
		echo "<script> alert('Maaf, Id Keluar : $id_keluar_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_keluar'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbskeluar
			(
			id_keluar,
			no_servis, 
			id_teknisi,
			tgl_keluar,
			id_kerusakan,
			id_sp,
			biaya_tambahan,
			total
			) 
			values
			(
			'$id_keluar_post',
			'$no_servis_post',
			'$id_teknisi_post',
			'$tgl_keluar_post',
			'$id_kerusakan_post',
			'$id_sp_post',
			'$biaya_tambahan_post',
			'$total_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=servis_keluar'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_keluar'>";	
		}
	}
	
?>