<?php
	include '../conn/koneksi.php';

	$no_srv_get = $_GET['no_srv_get'];

	//echo $id_tek_get;

	
	$query 	= mysql_query("DELETE FROM tbservis WHERE no_servis='$no_srv_get'");

	if ($query) {
		//unlink("../files/$data['file']");
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";
	}
	
?>