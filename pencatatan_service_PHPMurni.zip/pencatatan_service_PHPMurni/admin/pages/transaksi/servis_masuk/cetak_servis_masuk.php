<?php

  include '../conn/koneksi.php';
  
  $no_servis_post  = $_POST['no_servis'];

  $query_servis    = "SELECT tbservis.*, 
                      tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
                      FROM tbservis
                      INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen) 
                      WHERE no_servis='$no_servis_post'
                      ";
  $sql_servis       = mysql_query($query_servis);
  $data_servis      = mysql_fetch_array($sql_servis);
  $no_servis_servis = $data_servis['no_servis'];
  $nama_konsumen    = $data_servis['nama'];
  $no_telp_konsumen = $data_servis['telp'];

?>


<body onLoad="window.print();">
  <section class="content" style="background-color: #fff;">
    <div class="">
      <table>
        <tr>
          <td style="width: 500px;">
            <h4>CV. BASIS COMPUTER</h4>
          </td>
          <td>
            <?php echo 'No Servis: '.$no_servis_post; ?>
          </td>
        </tr>
        <tr>
          <td style="width: 500px;">
            Jl. Raya Siteba no 47
          </td>
          <td>
            
            Tgl Masuk: <?php echo date('d-m-Y') ?>
          </td>
        </tr>
        <tr>
          <td style="width: 500px;">
            No Telp: 081363780075
          </td>
          <td>
            <?php echo 'Nama Konsumen: '.$nama_konsumen; ?>
          </td>
        </tr>
        <tr>
          <td style="width: 500px;">
            www.basiscomputer.com
          </td>
          <td>
            <?php echo 'No Hp: '.$no_telp_konsumen ?>
          </td>
        </tr>
      </table>
      <hr style="margin-top: 8px;">
      <h4 align="center" style="margin-bottom: -20px; margin-top: -15px;">Tanda Terima Barang Servis</h4>
    <!-- /.box-header -->
    <div class="box-body">
      <div class="box-header">
        <div class="box-tools">
          
        </div>
      </div>
      <!-- /.box-header -->
      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr>
            <th style="vertical-align: middle; text-align: center; width: 150px;">Nama Barang</th>
            <th style="vertical-align: middle; text-align: center; width: 120px;">Jenis Barang</th>
            <th style="vertical-align: middle; text-align: center; width: 250px;">Kerusakan</th>
            <th style="vertical-align: middle; text-align: center;">Kelengkapan</th>
          </tr>
          <?php
            $query  = "SELECT tbservis.*, 
                        tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
                        FROM tbservis
                        INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen) 
                        WHERE no_servis='$no_servis_post'
                      ";
            $sql    = mysql_query($query);
            $total  = mysql_num_rows($sql);
            $no     = 1;
            
            while ($data=mysql_fetch_array($sql)) {
          ?>
          <tr>
            <td style="vertical-align: middle; text-align: center;"><?php echo $data['nama_barang']; ?></td>
            <td style="vertical-align: middle; text-align: center;"><?php echo $data['jenis_barang']; ?></td>
            <td style="vertical-align: middle; text-align: center;"><?php echo $data['desc_kerusakan']; ?></td>
            <td style="vertical-align: middle; text-align: center;"><?php echo $data['kelengkapan']; ?></td>
          </tr>
          <?php $no++; } ?>
        </table>
        <hr style="margin-top: 8px;">
        <table align="center">
          <tr">
            <td align="center" style="">Konsumen</td>
            <td style="width: 400px;"></td>
            <td align="center">Hormat Saya</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>
          <tr>
            <td align="center" style="">Nama Konsumen</td>
            <td style="width: 400px;"></td>
            <td align="center">Admin</td>
          </tr>
        </table>
      </div>
    </div>
    <!-- /.box-body -->
  </div>
</section>
</body>