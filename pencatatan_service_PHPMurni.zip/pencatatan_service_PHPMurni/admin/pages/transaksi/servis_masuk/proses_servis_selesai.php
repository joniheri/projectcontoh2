<?php 
	//echo $no_srv_get = $_GET['no_srv_kirim'];
	//echo 'ID Teknisi : '.$id_teknisi = $_POST['id_teknisi'];
?>

<?php
	/*
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	*/
	include '../conn/koneksi.php';

	$no_srv_get 			= $_GET['no_srv_kirim'];

	$id_teknisi_post 		= $_POST['id_teknisi'];
	$status_post			= "Telah Selesai";

	//echo 'ID Awal : '.$id_kon_get.'<br> ID Akhir : '.$id_konsumen_post;

	$input=mysql_query("
			UPDATE tbservis SET
			id_teknisi 		='$id_teknisi_post',
			status          ='$status_post'
			WHERE  no_servis='$no_srv_get'
		");
		if ($input) {
			echo "<script> alert('Update data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";	
		}
		else {
			echo "<script> alert('Update data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_status_servis&no_srv_kirim=$no_srv_get'>";	
		}
?>
