
<?php 
	$no_servis_get 		= $_GET['no_svr_kirim'];
	$id_kerusakan_get 	= $_GET['id_kerusakan_kirim'];

	$input=mysql_query("
		INSERT INTO tbtransaksi
		(
		no_servis, 
		id_kerusakan_sp,
		jenis_servis
		) 
		values
		(
		'$no_servis_get',
		'$id_kerusakan_get',
		'Kerusakan'
		)
	");
	if ($input) {
		echo "<script> alert('Proses BERHASIL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_kerusakan&no_svr_kirim=$no_servis_get'>";	
	}
	else {
		echo "<script> alert('Proses GAGAL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_kerusakan&no_svr_kirim=$no_servis_get'>";	
	}
?>