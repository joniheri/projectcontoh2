<?php 
  include '../conn/koneksi.php';
  include '../conn/autoid.php';

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM SERVICE MASUK</h3>
    </div>
    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_tambah_servis_masuk" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">
            <!-- autono masuk -->
              <input type="hidden" class="form-control" name="no_servis" value="<?= $auto_nosmsk ?>" id="" placeholder="" >
            <!-- end autono masuk -->
            <div class="form-group">
              <label for="exampleInputPassword1">Id Konsumen - Nama Konsumen </label>
              <select name="id_konsumen" class="form-control select2" style="width: 100%;" required="required">
                <option value="">--Pilih--</option>
                <?php
                  $query  = "SELECT * FROM tbkonsumen";
                  $sql    = mysql_query($query);
                  $total  = mysql_num_rows($sql);
                  $no     = 1;
                  
                  while ($data=mysql_fetch_array($sql)) {
                ?>
                <option value="<?php echo $data['id_konsumen'] ?>"><?php echo $data['id_konsumen'].' - '.$data['nama'] ?></option>
                <?php
                  }
                ?>
              </select>
            </div>
             <div class="form-group">
              <label for="exampleInputEmail1">Tgl Masuk</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input type="text" class="form-control" name="tgl_masuk" value="<?php echo date('Y-m-d') ?>" data-inputmask="'alias': 'yyyy-mm-dd'" data-mask>
              </div>
            </div>
             <div class="form-group">
              <label for="exampleInputPassword1">Nama Barang</label>
              <input type="text" class="form-control" name="nama_barang" id="" placeholder="Nama Barang" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Barang</label>
              <input type="text" class="form-control" name="jenis_barang" id="" placeholder="Jenis Barang" required="required">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
                  <label for="exampleInputPassword1">Keluhan</label>
                  <textarea type="text" class="form-control" name="desc_kerusakan" rows="3" placeholder="Desc Kerusakan" required="required"></textarea>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Kelengkapan Barang</label>
              <input type="text" class="form-control" name="kelengkapan" id="" placeholder="Kelengkapan Barang" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->
        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <button type="reset" href="?page=tambah_servis_masuk" class="btn btn-warning" title="" style="margin-right: 5px;"><i class="fa fa-remove"></i> Batal</button>
            <a href="?page=servis_masuk" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>