<?php
	include '../conn/koneksi.php';

	$no_servis_get = $_GET['no_srv_kirim'];
	//echo 'edit status disini, dengan no servis : $no_servis_get';

	$input=mysql_query("
		UPDATE tbservis SET
		status 	='Telah Selesai'
		WHERE  no_servis='$no_servis_get'
	");
	if ($input) {
		echo "<script> alert('Update Servis Selesai BERHASIL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";	
	}
	else {
		echo "<script> alert('Update data GAGAL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";	
	}
?>