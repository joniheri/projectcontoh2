<?php
	include '../conn/koneksi.php';

	$no_servis_get = $_GET['no_srv_kirim'];
?>

<section class="content">
	<div class="box box-info">
		<div class="box-header with-border">
			<h3 class="box-title">Pemilihan Data Sparepart</h3>
		</div>
		<div class="box-body">
			<div class="box-body table-responsive no-padding">
				<table class="table table-hover">
					<tr style="background-color: #7DB3D2;">
						<th width="" style="vertical-align: middle; text-align: center;">Nama Kerusakan</th>
						<th width="" style="vertical-align: middle; text-align: center;">Harga</th>
						<th width="50" style="vertical-align: middle; text-align: center;">Aksi</th>
					</tr>
					<?php 
						$query  = "SELECT *
							FROM tbsparepart
							ORDER BY id_sp ASC
						";
						$sql    = mysql_query($query);
						$total  = mysql_num_rows($sql);
						$no     = 1;

						while ($data=mysql_fetch_array($sql)) {
					?>
					<tr>
						<td><?php echo $data['nama_sp']; ?></td>
						<td><?php echo $data['harga_sp']; ?></td>
						<td>
							<a class="btn btn-success btn-default" style="color: #ffffff;" title="Pilih" href="?page=proses_simpan_tambah_servis_sparepart&id_sp_kirim=<?php echo $data['id_sp']; ?>&no_srv_kirim=<?php echo $no_servis_get; ?>">Pilih</a>
						</td>
					</tr>
					<?php } ?>
				</table>
			</div>
		</div>
		<div class="box-footer">
			<div class="col-md-12">
				<a href="?page=edit_status_servis&no_srv_kirim=<?php echo $no_servis_get; ?>" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Selesai</a>
			</div>
		</div>
	</div>
</section>