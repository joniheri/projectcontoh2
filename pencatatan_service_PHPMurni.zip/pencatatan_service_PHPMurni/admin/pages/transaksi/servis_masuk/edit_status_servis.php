<?php

	include '../conn/koneksi.php';
  	
  	$no_servis_get  = $_GET['no_srv_kirim'];

  	//mencari data servis
	$query_servis    = "SELECT tbservis.*, 
		tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
		FROM tbservis
		INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen) 
		WHERE no_servis='$no_servis_get'
 	";
	$sql_servis       = mysql_query($query_servis);
	$data_servis      = mysql_fetch_array($sql_servis);
	$no_servis_servis = $data_servis['no_servis'];
	$nama_konsumen    = $data_servis['nama'];
	$no_telp_konsumen = $data_servis['telp'];
	$alamat_konsumen 	= $data_servis['alamat'];
	$tgl_masuk 			= $data_servis['tgl_masuk'];
	$nama_barang 		= $data_servis['nama_barang'];
	$jenis_barang		= $data_servis['jenis_barang'];
	$keluhan 			= $data_servis['desc_kerusakan'];
	$id_teknisi 		= $data_servis['id_teknisi'];
	//=============================================================

	//mencari data id teknisi
	$query_it_teknisi    = "SELECT *
		FROM tbteknisi
		WHERE id_teknisi = '$id_teknisi'
 	";
 	$sql_id_teknisi 	= mysql_query($query_it_teknisi);
 	$data_id_teknisi    = mysql_fetch_array($sql_id_teknisi);
 	$nama_id_teknisi 	= $data_id_teknisi['nama_teknisi'];
 	//=============================================================

?>

<body onLoad="">
	<section class="content" style="">
		<div class="">
			<div class="box box-info">
				<div class="box-header with-border">
	              <h3 class="box-title">Deskripsi Servis</h3>
	            </div>
				<div class="box-body">
					<div class="col-md-6">
						<table>
							<tr>
								<td style="width: 120px;">No Servis</td>
								<td style="width: 10px;">:</td>
								<td><?php echo $no_servis_get; ?></td>
							</tr>
							<tr>
							  <td style="">Nama Konsumen</td>
							  <td>:</td>
							  <td><?php echo $nama_konsumen; ?></td>
							</tr>
							<tr>
							  <td style="">Alamat Konsumen</td>
							  <td>:</td>
							  <td><?php echo $alamat_konsumen; ?></td>
							</tr>
							<tr>
							  <td style="">Telp. Konsumen</td>
							  <td>:</td>
							  <td><?php echo $no_telp_konsumen; ?></td>
							</tr>
						</table>
					</div>
					<div class="col-md-6">
						<table>
							<tr>
							  <td style="width: 120px;">Tgl Masuk</td>
							  <td style="width: 10px;">:</td>
							  <td><?php echo $no_servis_get; ?></td>
							</tr>
							<tr>
							<tr>
							  <td style="">Nama Barang</td>
							  <td>:</td>
							  <td><?php echo $nama_barang; ?></td>
							</tr>
							  <td style="">Jenis Barang</td>
							  <td>:</td>
							  <td><?php echo $jenis_barang; ?></td>
							</tr>
							<tr>
							  <td style="">Keluhan</td>
							  <td>:</td>
							  <td><?php echo $keluhan; ?></td>
							</tr>
						</table>
					</div>
				</div>
			</div>
			<!-- /.box-header -->
			
			<form class="form-horizontal" method="post" action="?page=proses_servis_selesai&no_srv_kirim=<?php echo $no_servis_get ; ?>">
				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Pilih Teknisi</h3>
					</div>
					<!-- /.box-header -->
					<div class="box-body">
						<div class="col-md-6">
							<div class="form-group">
								<div class="col-sm-10">
									<select name="id_teknisi" class="form-control select2" style="width: 100%;" required="required">
										<?php
											$pilih_nama_teknisi;
											$nama_teknisi_terpilih;
											if($nama_id_teknisi == ""){
												$pilih_nama_teknisi = '<option value="" selected="selected">--Pilih--</option>';
												$nama_teknisi_terpilih='';
											}
											else if($nama_id_teknisi != ''){
												$pilih_nama_teknisi 	= '<option value="">--Pilih--</option>';
												$nama_teknisi_terpilih	='<option value="$id_teknisi" selected="selected">'.$id_teknisi.' - '.$nama_id_teknisi.'</option>';
											}
											echo $pilih_nama_teknisi;
											echo $nama_teknisi_terpilih;
											/*
											*/
										?>
										<!--
										<option value="$id_teknisi" selected="selected"><?php //echo $nama_id_teknisi.' - '.$nama_id_teknisi; ?></option>
										-->
										<?php
											$query_teknisi  = "SELECT *
												FROM tbteknisi
												ORDER BY id_teknisi ASC
											";
											$sql_teknisi    = mysql_query($query_teknisi);
											$total_teknisi  = mysql_num_rows($sql_teknisi);
											$no_teknisi     = 1;

											while ($data_teknisi=mysql_fetch_array($sql_teknisi)) {
										?>
										<option value="<?php echo $data_teknisi['id_teknisi']; ?>"><?php echo $data_teknisi['id_teknisi'].'-'.$data_teknisi['nama_teknisi']; ?></option>
										<?php } ?>
									</select>
								</div>
							</div>
						</div>
						<div class="col-md-6">

						</div>
					</div>
	        	</div>

				<div class="box box-info">
					<div class="box-header with-border">
		              <h3 class="box-title">Kerusakan</h3>
		              <a style="margin-right: 5px;" href="?page=tambah_servis_kerusakan&no_svr_kirim=<?php echo $no_servis_get; ?>" class="btn btn-default pull-right" title="Tambah data"><i class="fa fa-plus"></i></a>
		            </div>
					<div class="box-body">
						<div class="box-body table-responsive no-padding">
							<table class="table table-hover">
								<tr style="background-color: #7DB3D2;">
									<th width="" style="vertical-align: middle; text-align: center;">Nama Kerusakan</th>
									<th width="" style="vertical-align: middle; text-align: center;">Harga</th>
									<th width="50" style="vertical-align: middle; text-align: center;">Aksi</th>
								</tr>
								<?php 
									$query_kerusakan  = "SELECT tbtransaksi.*,
										tbkerusakan.nama_kerusakan, tbkerusakan.harga_kerusakan
										FROM `tbtransaksi`
										INNER JOIN tbkerusakan on (tbtransaksi.id_kerusakan_sp=tbkerusakan.id_kerusakan)
										WHERE no_servis = '$no_servis_get'
										ORDER BY id_transaksi ASC
									";
									$sql_kerusakan    = mysql_query($query_kerusakan);
									$total_kerusakan  = mysql_num_rows($sql_kerusakan);
									$no_kerusakan     = 1;
									$sub_total_harga_kerusakan=0;
									while ($data_kerusakan=mysql_fetch_array($sql_kerusakan)) {
										$sub_total_harga_kerusakan = $data_kerusakan['harga_kerusakan'] + $sub_total_harga_kerusakan;
								?>
								<tr>
									<td><?php echo $data_kerusakan['nama_kerusakan'] ?></td>
									<td><?php echo $data_kerusakan['harga_kerusakan'] ?></td>
									<td>
										<a class="btn btn-danger btn-default" style="color: #ffffff;" title="Hapus" href="?page=proses_hapus_servis_kerusakan&no_srv_kirim=<?php echo $no_servis_get; ?>&id_transaksi_kirim=<?php echo $data_kerusakan['id_transaksi']; ?>" onClick="return confirm('Yakin ingin menghapus data ini..?');"><i class="fa fa-trash"></i></a>
									</td>
								</tr>
								<?php } ?>
								<tr style="background: #222D32; color: #ffffff;">
									<td><h4 style="margin-top: 1px; margin-bottom: 1px;">Sub total harga kerusakan : </h4></td>
									<td><h4 style="margin-top: 1px; margin-bottom: 1px;"><?php echo $sub_total_harga_kerusakan; ?></h4></td>
									<td></td>
								</tr>
							</table>
						</div>
					</div>
				</div>

				<div class="box box-info">
					<div class="box-header with-border">
						<h3 class="box-title">Sparepart</h3>
						<a style="margin-right: 5px;" href="?page=tambah_servis_sparepart&no_srv_kirim=<?php echo $no_servis_get; ?>" class="btn btn-default pull-right" title="Tambah data"><i class="fa fa-plus"></i></a>
					</div>
					<div class="box-body">
						<table class="table table-hover">
							<tr style="background-color: #7DB3D2;">
								<th width="" style="vertical-align: middle; text-align: center;">Nama Sparepart</th>
								<th width="" style="vertical-align: middle; text-align: center;">Harga</th>
								<th width="50" style="vertical-align: middle; text-align: center;">Aksi</th>
							</tr>
							<?php 
									$query_sparepart  = "SELECT tbtransaksi.*,
										tbsparepart.nama_sp, tbsparepart.harga_sp
										FROM `tbtransaksi`
										INNER JOIN tbsparepart on (tbtransaksi.id_kerusakan_sp=tbsparepart.id_sp)
										WHERE no_servis = '$no_servis_get'
										ORDER BY id_transaksi ASC
									";
									$sql_sp    = mysql_query($query_sparepart);
									$total_sp  = mysql_num_rows($sql_sp);
									$no_sp     = 1;
									$sub_total_harga_sparepart=0;
									while ($data_sp=mysql_fetch_array($sql_sp)) 
									{
										$sub_total_harga_sparepart = $data_sp['harga_sp'] + $sub_total_harga_sparepart;
								?>
							<tr>
								<td><?php echo $data_sp['nama_sp']; ?></td>
								<td><?php echo $data_sp['harga_sp']; ?></td>
								<td>
										<a class="btn btn-danger btn-default" style="color: #ffffff;" title="Hapus" href="?page=proses_hapus_servis_kerusakan&no_srv_kirim=<?php echo $no_servis_get; ?>&id_transaksi_kirim=<?php echo $data_sp['id_transaksi']; ?>" onClick="return confirm('Yakin ingin menghapus data ini..?');"><i class="fa fa-trash"></i></a>
								</td>
							</tr>
							<?php } ?>
							<tr style="background: #222D32; color: #ffffff;">
									<td><h4 style="margin-top: 1px; margin-bottom: 1px;">Sub total harga sparepart : </h4></td>
									<td><h4 style="margin-top: 1px; margin-bottom: 1px;"><?php echo $sub_total_harga_sparepart; ?></h4></td>
									<td></td>
							</tr>
						</table>
					</div>
				</div>

				<div class="box box-info">
					<div class="box-header with-border" style="margin-bottom: -5px;">
						<h3 class="box-title">Total Biaya</h3>
					</div>
					<div class="box-body">
						<table class="table table-hover">
							<tr style="background: #1D965E; color: #ffffff;">
								<?php
								$total = $sub_total_harga_kerusakan + $sub_total_harga_sparepart
								?>
								<td><h4 style="margin-top: 1px; margin-bottom: 1px;"><?php echo 'Total : ' .$total; ?></h4></td>
							</tr>
						</table>
					</div>
				</div>

				<div class="box box-default">
					<div class="box-body">
						<button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
						<a href="?page=servis_masuk" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
					</div>
				</div>
			</form>

		</div>
	</section>
</body>


