<?php
	include '../conn/koneksi.php';

	$no_srv_get = $_GET['no_srv_kirim'];

	$query           = "SELECT tbservis.*, 
                      tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
                      FROM tbservis
                      INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen) 
                      WHERE no_servis='$no_srv_get'
                      ";
	$sql             = mysql_query($query);
	$data            = mysql_fetch_array($sql);
  $no_servis       = $data['no_servis'];
	$id_konsumen     = $data['id_konsumen'];
  $nama            = $data['nama'];
	$tgl_masuk       = $data['tgl_masuk'];
  $nama_barang     = $data['nama_barang'];
  $jenis_barang    = $data['jenis_barang'];
  $desc_kerusakan  = $data['desc_kerusakan'];
  $kelengkapan     = $data['kelengkapan'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">FORM EDIT SERVICE MASUK</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body">
      <form method="post" action="?page=proses_simpan_edit_servis_masuk&no_srv_kirim=<?php echo $no_srv_get;?>" enctype="multipart/form-data">
        <div class="box-body">
          <div class="col-md-6">

            <input type="hidden" class="form-control" name="no_servis" value="<?php echo $no_servis; ?>" id="" placeholder="" required="required">

            <div class="form-group">
              <label for="exampleInputPassword1">Id Konsumen</label>
              <input type="text" class="form-control" disabled="disabled" name="id_konsumen" value="<?php echo $id_konsumen.'-'.$nama; ?>" id="" placeholder="Id Konsumen" required="required">
            </div>
             <div class="form-group">
              <label for="exampleInputEmail1">Tgl Masuk</label>
              <div class="input-group">
                <div class="input-group-addon">
                  <i class="fa fa-calendar"></i>
                </div>
                <input type="text" class="form-control" name="tgl_masuk" value="<?php echo $tgl_masuk; ?>" data-inputmask="'alias': 'yyyy-mm-dd'" data-mask>
              </div>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Nama Barang</label>
              <input type="text" class="form-control" name="nama_barang" value="<?php echo $nama_barang; ?>" id="" placeholder="Nama Barang" required="required">
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Jenis Barang</label>
              <input type="text" class="form-control" name="jenis_barang" value="<?php echo $jenis_barang; ?>" id="" placeholder="Jenis Barang" required="required">
            </div>
          </div>
          <div class="col-md-6">
            <div class="form-group">
              <label for="exampleInputPassword1">Keluhan</label>
              <textarea type="text" class="form-control" name="desc_kerusakan" rows="3" placeholder="Desc Kerusakan" required="required"><?php echo $desc_kerusakan; ?></textarea>
            </div>
            <div class="form-group">
              <label for="exampleInputPassword1">Kelengkapan Barang</label>
              <input type="text" class="form-control" name="kelengkapan" value="<?php echo $kelengkapan; ?>" id="" placeholder="Kelengkapan Barang" required="required">
            </div>
          </div>
        </div>
        <!-- /.box-body -->

        <div class="box-footer">
          <div class="col-md-12">
            <button type="submit" class="btn btn-success" title="" style="margin-right: 5px;"><i class="fa fa-check"></i> Simpan</button>
            <a href="?page=servis_masuk" class="btn btn-primary" title="" style="margin-right: 5px;"><i class="fa fa-arrow-left"></i> Kembali</a>
          </div>
        </div>
        <!-- /.box-footer-->
      </form>
    </div>
    <!-- /.box-body -->
  </div>
</section>