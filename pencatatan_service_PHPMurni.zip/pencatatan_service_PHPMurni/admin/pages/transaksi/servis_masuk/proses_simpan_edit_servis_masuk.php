<?php
	/*
	$username_session       = $_SESSION['username'];
	$password_session       = $_SESSION['password'];
	$nama_pengguna_session  = $_SESSION['nama_pengguna'];
	$hak_akses_session      = $_SESSION['hak_akses'];
	*/
	include '../conn/koneksi.php';

	$no_srv_get 			= $_GET['no_srv_kirim'];

	$no_servis_post			= $_POST['no_servis'];
	$id_konsumen_post 		= $_POST['id_konsumen'];
	$tgl_masuk_post 		= $_POST['tgl_masuk'];
	$nama_barang_post 		= strtoupper($_POST['nama_barang']);
	$jenis_barang_post 		= strtoupper($_POST['jenis_barang']);
	$desc_kerusakan_post 	= strtoupper($_POST['desc_kerusakan']);
	$kelengkapan_post 		= strtoupper($_POST['kelengkapan']);

	//echo 'ID Awal : '.$id_kon_get.'<br> ID Akhir : '.$id_konsumen_post;

	if($no_servis_post == $no_srv_get){
		$input=mysql_query("
			UPDATE tbservis SET
			tgl_masuk 		='$tgl_masuk_post',
			nama_barang 	='$nama_barang_post',
			jenis_barang 	='$jenis_barang_post',
			desc_kerusakan  ='$desc_kerusakan_post',
			kelengkapan 	='$kelengkapan_post'
			WHERE  no_servis='$no_srv_get'
		");
		if ($input) {
			echo "<script> alert('Update data BERHASIL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";	
		}
		else {
			echo "<script> alert('Update data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_servis_masuk&no_srv_kirim=$no_srv_get'>";	
		}
	}

	else{
		$query_no_servis=mysql_query("SELECT * FROM tbservis where no_servis='$no_servis_post'");
		$cek=mysql_num_rows($query_no_servis);
		if ($cek>0) {
			echo "<script> alert('Maaf, No Servis : $no_servis_post, SUDAH ADA.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=edit_servis_masuk&no_srv_kirim=$no_srv_get'>";
		}

		else{
			$input=mysql_query("
				UPDATE tbservis SET
				no_servis 		='$no_servis_post',
				tgl_masuk 		='$tgl_masuk_post',
				nama_barang 	='$nama_barang_post',
				jenis_barang 	='$jenis_barang_post',
				desc_kerusakan  ='$desc_kerusakan_post',
				kelengkapan 	='$kelengkapan_post'
				WHERE  no_servis='$no_srv_get'
			");
			if ($input) {
				echo "<script> alert('Update data BERHASIL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";	
			}
			else {
				echo "<script> alert('Update data GAGAL.') </script>";
				echo "<meta http-equiv='refresh' content='0; url=?page=edit_servis_masuk&no_srv_kirim=$no_srv_get'>";
			}
		}
	}

?>
