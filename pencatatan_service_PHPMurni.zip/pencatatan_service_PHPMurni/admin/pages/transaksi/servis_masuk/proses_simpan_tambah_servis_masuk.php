<?php
	include '../conn/koneksi.php';

	$no_servis_post 		= $_POST['no_servis'];
	$id_konsumen_post 		= $_POST['id_konsumen'];
	$tgl_masuk_post 		= $_POST['tgl_masuk'];
	$nama_barang_post 		= strtoupper($_POST['nama_barang']);
	$jenis_barang_post 		= strtoupper($_POST['jenis_barang']);
	$desc_kerusakan_post 	= strtoupper($_POST['desc_kerusakan']);
	$kelengkapan_post 		= strtoupper($_POST['kelengkapan']);
	$status_post 			= "Belum Selesai";

	//echo "$no_servis_post , $id_konsumen_post, $tgl_masuk_post, $nama_barang_post, $jenis_barang_post, $desc_kerusakan_post, $kelengkapan_post, $status_post  ";

	$query_no_servis=mysql_query("SELECT * FROM tbservis where no_servis='$no_servis_post'");
	$cek=mysql_num_rows($query_no_servis);
	if ($cek>0) {
		echo "<script> alert('Maaf, No Servis : $no_servis_post, SUDAH ADA.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_data_servis_masuk'>";
	}

	else{
		$input=mysql_query("
			INSERT INTO tbservis
			(
			no_servis, 
			id_konsumen,
			tgl_masuk,
			nama_barang,
			jenis_barang,
			desc_kerusakan,
			kelengkapan,
			status
			) 
			values
			(
			'$no_servis_post',
			'$id_konsumen_post',
			'$tgl_masuk_post',
			'$nama_barang_post',
			'$jenis_barang_post',
			'$desc_kerusakan_post',
			'$kelengkapan_post',
			'$status_post'
			)
		");
		if ($input) {
			echo "<script> alert('Menambah data BERHASIL.') </script>";
			//echo "<meta http-equiv='refresh' content='0; url=?page=cetak_servis_masuk'>";	
		}
		else {
			echo "<script> alert('Menambah data GAGAL.') </script>";
			echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_masuk'>";	
		}
	}
?>