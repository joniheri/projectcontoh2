
<?php 
	$id_sp_get 		= $_GET['id_sp_kirim'];
	$no_servis_get 	= $_GET['no_srv_kirim'];

	$input=mysql_query("
		INSERT INTO tbtransaksi
		(
		no_servis, 
		id_kerusakan_sp,
		jenis_servis
		) 
		values
		(
		'$no_servis_get',
		'$id_sp_get',
		'Sparepart'
		)
	");
	if ($input) {
		echo "<script> alert('Proses BERHASIL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_sparepart&no_srv_kirim=$no_servis_get'>";	
	}
	else {
		echo "<script> alert('Proses GAGAL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=tambah_servis_sparepart&no_srv_kirim=$no_servis_get'>";	
	}
?>