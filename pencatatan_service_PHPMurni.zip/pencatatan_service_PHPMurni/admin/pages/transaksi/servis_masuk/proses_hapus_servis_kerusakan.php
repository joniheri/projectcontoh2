proses hapus disini
<?php 
	$id_transaksi_get 	= $_GET['id_transaksi_kirim'];
	$no_srv_get 		= $_GET['no_srv_kirim'];
	
	$query 	= mysql_query("DELETE FROM tbtransaksi WHERE id_transaksi='$id_transaksi_get'");

	if ($query) {
		echo "<script>alert('Menghapus data BERHASIL.')</script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=edit_status_servis&no_srv_kirim=$no_srv_get'>";
	} else {
		echo "<script>alert('Menghapus data GAGAL.')</script>.";
		echo "<meta http-equiv='refresh' content='0; url=?page=edit_status_servis&no_srv_kirim=$no_srv_get'>";
	}
	
?>