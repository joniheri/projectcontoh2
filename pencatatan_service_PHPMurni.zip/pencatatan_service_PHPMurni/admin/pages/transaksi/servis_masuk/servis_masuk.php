<?php
  include '../conn/koneksi.php';

  $cari_post = $_POST['cari'];

?>

<section class="content">
  <div class="box box-primary">
    <div class="box-header with-border">
      <h3 class="box-title">DATA SERVICE MASUK</h3>
    </div>

    <!-- /.box-header -->
    <div class="box-body no-padding">
      <form method="post" action="?page=servis_masuk">
        <div class="box-header">
          <a style="margin-right: 5px;" href="?page=tambah_servis_masuk" class="btn btn-social-icon btn-linkedin" title="Tambah data"><i class="fa fa-plus"></i></a>
          <div class="box-tools">
            <div class="input-group input-group-sm" style="width: 150px;">
              <input type="text" name="cari" class="form-control pull-right" placeholder="Search">
              <div class="input-group-btn">
                <button type="submit" class="btn btn-default"><i class="fa fa-search"></i></button>
              </div>
            </div>
          </div>
        </div>
      </form>
      <!-- /.box-header -->

      <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
          <tr style="background-color: #222D32; color: #C9CCCD;">
            <th width="100" style="vertical-align: middle; text-align: center;">Nama Kerusakan</th>
            <th width="120" style="vertical-align: middle; text-align: center;">Harga</th>
            <th width="120" style="vertical-align: middle; text-align: center; ">Alamat</th>
            <th width="120" style="vertical-align: middle; text-align: center;">Telp</th>
            <th width="100" style="vertical-align: middle; text-align: center;">Tgl Masuk</th>
            <th width="150" style="vertical-align: middle; text-align: center;"> Nama Barang </th>
            <th width="100" style="vertical-align: middle; text-align: center;">Jenis Barang</th>
            <th width="250" style="vertical-align: middle; text-align: center;">Keluhan</th>
            <th width="140" style="vertical-align: middle; text-align: center;">Kelengkapan Barang</th>
            <th width="120" style="vertical-align: middle; text-align: center;">Status</th>
            <th width="30" style="vertical-align: middle; text-align: center;">Aksi</th>
          </tr>
          <?php
            $query  = "SELECT tbservis.*, 
                      tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
                      FROM tbservis
                      INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen)
                      WHERE status !='Telah Diambil'
                      ORDER BY no_servis ASC
            ";
            $sql    = mysql_query($query);
            $total  = mysql_num_rows($sql);
            $no     = 1;
            
            while ($data=mysql_fetch_array($sql)) {
              $file = $data['file'];
          ?>
          <tr>
            <td style="vertical-align: middle;"><?php echo $data['no_servis']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['nama']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['alamat']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['telp']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['tgl_masuk']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['nama_barang']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['jenis_barang']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['desc_kerusakan']; ?></td>
            <td style="vertical-align: middle;"><?php echo $data['kelengkapan']; ?></td>
            <td style="vertical-align: middle; text-align: center;"><?php echo $data['status']; ?></td>
            <td style="vertical-align: middle; text-align: center;">

              <!-- btn dropdown jn -->
              <div class="btn-group">
                <button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown" style="min-width: 30px;">
                  <i class="glyphicon glyphicon-menu-hamburger"></i>
                </button>
                <ul class="dropdown-menu pull-right" role="menu">
                  <?php
                    $tombol_update_status;
                    $tombol_take_out;
                    $data_no_servis =  $data['no_servis'];
                    if ($data['status'] == 'Telah Selesai'){
                      $tombol_update_status = "<li><a href='?page=edit_status_servis&no_srv_kirim=$data_no_servis'><i class='fa fa-pencil'></i>Edit Selesai</a></li>";
                      $tombol_take_out      = "<li><a href='?page=take_out&no_srv_kirim=$data_no_servis' onClick='return confirm('Yakin ingin melakukan Take Out data ini...?');'><i class='fa fa-sign-out'></i>Take Out</a></li>";
                    }
                    else{
                      $tombol_update_status = "<li><a href='?page=edit_status_servis&no_srv_kirim=$data_no_servis'><i class='fa fa-check'></i>Selesai</a></li>";
                      $tombol_take_out      = "";
                    }
                  ?>
                  <li><a href="?page=button_cetak_servis_masuk&no_srv_kirim=<?php echo $data['no_servis']; ?>"><i class='fa fa-print'></i>Print</a></li>
                  <li><a href="?page=edit_servis_masuk&no_srv_kirim=<?php echo $data['no_servis']; ?>"><i class='fa fa-pencil'></i>Edit</a></li>
                  <?php 
                    echo $tombol_update_status;
                    echo $tombol_take_out; 
                  ?>
                </ul>
              </div>
            </td>
          </tr>
          <?php $no++; } ?>
        </table>
      </div>
    </div>
    <!-- /.box-body -->
  </div>
</section>