<?php

	include '../conn/koneksi.php';

	$no_servis_get  = $_GET['no_srv_kirim'];
	$tanggal_keluar = date('Y-m-d');
	$input=mysql_query("
		UPDATE tbservis SET
		tgl_keluar='$tanggal_keluar',
		status='Telah Diambil'
		WHERE no_servis='$no_servis_get'
	");
	if ($input) {
		echo "<script> alert('Take Out data BERHASIL.') </script>";
		//echo "<meta http-equiv='refresh' content='0; url=?page=data_konsumen'>";
	}
	else {
		echo "<script> alert('Update data GAGAL.') </script>";
		echo "<meta http-equiv='refresh' content='0; url=?page=servis_masuk'>";	
	}

	//Format rupiah
	function rupiah($angka){
	$hasil_rupiah = "Rp " . number_format($angka,2,',','.');
	return $hasil_rupiah;
	}
	//echo rupiah(1000000);
	//====================================


	$query_servis 	= "SELECT tbservis.*, 
		tbkonsumen.nama, tbkonsumen.jk, tbkonsumen.alamat, tbkonsumen.telp
		FROM tbservis
		INNER JOIN tbkonsumen ON (tbservis.id_konsumen=tbkonsumen.id_konsumen) 
		WHERE no_servis='$no_servis_get'
	";
	$sql_servis 		= mysql_query($query_servis);
	$data_servis 		= mysql_fetch_array($sql_servis);
	$no_servis_servis 	= $data_servis['no_servis'];
	$nama_konsumen 		= $data_servis['nama'];
	$no_telp_konsumen 	= $data_servis['telp'];
	$id_teknisi 		= $data_servis['id_teknisi'];
	$tgl_masuk 			= $data_servis['tgl_masuk'];
	$nama_barang 		= $data_servis['nama_barang'];
	$jenis_barang 		= $data_servis['jenis_barang'];

	//mencari data id teknisi
	$query_id_teknisi    = "SELECT *
		FROM tbteknisi
		WHERE id_teknisi = '$id_teknisi'
 	";
 	$sql_id_teknisi 	= mysql_query($query_id_teknisi);
 	$data_id_teknisi    = mysql_fetch_array($sql_id_teknisi);
 	$nama_id_teknisi 	= $data_id_teknisi['nama_teknisi'];
 	//=============================================================

?>

<body onLoad="window.print();">
	<section class="content" style="background-color: #fff;">
		<div class="">
			<h4 align="center">CV. BASIS COMPUTER</h4>
			<hr style="margin-top: 10px; margin-bottom: 10px;">
			<table style="font-size: 11px;">
				<tr>
					<td style="width: 250px;"><?php echo 'No Servis: '.$no_servis_get; ?> </td>
					<td style="width: 250px;">Tgl Masuk: <?php echo date('d-m-Y') ?></td>
					<td><?php echo 'Nama Teknisi: '.$nama_id_teknisi; ?></td>
				</tr>
				<tr>
					<td style="width: 250px;">Jl. Raya Siteba no 47</td>
					<td>Tgl Keluar: <?php echo $tgl_masuk; ?></td>
					<td><?php echo 'Nama Barang: '.$nama_barang; ?></td>
				</tr>
				<tr>
					<td style="width: 250px;">No Telp: 081363780075</td>
					<td><?php echo 'Nama Pelanggan: '.$nama_konsumen; ?></td>
					<td><?php echo 'Jenis Barang: '.$jenis_barang; ?></td>
				</tr>
				<tr>
					<td style="width: 250px;">www.basisconputer.com</td>
					<td><?php echo 'No Telp: '.$no_telp_konsumen; ?></td>
				</tr>
				<tr>
					<td></td>
					<td></td>
				</tr>
			</table>
			<table>
				<tr>
					<td style="width: 500px;"><?php //echo 'Teknisi: '.$id_teknisi; ?> </td>
					<td></td>
				</tr>
			</table>
			<div style="background: #CDD0D1; font-size: 12px;">
				<hr style="margin-top: 15px;">
				<h4 align="center" style="margin-bottom: -25px; margin-top: -10px; padding-bottom: 10px;">Service Invoice</h4>
			</div>
			<!-- /.box-header -->
			<div class="box-body">
				<div class="box-header">
					<div class="box-tools">

					</div>
				</div>
				<!-- /.box-header -->
				<div class="box-body table-responsive no-padding">
					<table class="table table-hover" style="font-size: 11px;">
						<tr style="font-weight: bold; text-transform: uppercase;">
							<th style="vertical-align: middle; text-align: center; width: 30px;">No</th>
							<th style="vertical-align: middle;"> Nama Kerusakan/Sparepart</th>
							<th style="vertical-align: middle; text-align: center; width: 140px;">Biaya/harga</th>
						</tr>
						<?php
						$query  = "SELECT *
							FROM `tbtransaksi`
							WHERE no_servis = '$no_servis_get'
							ORDER BY id_transaksi ASC
						";
						$sql    = mysql_query($query);
						$total  = mysql_num_rows($sql);
						$no     = 1;
						$total_biaya = 0;

						while ($data=mysql_fetch_array($sql)) {
						?>
						<tr>
							<td style="vertical-align: middle; text-align: right;"><?php echo $no; ?></td>
							<?php

								$id_kerusakan_sp = $data['id_kerusakan_sp'];

								//cari data kerusakan
								$query_kerusakan  = "SELECT *
									FROM `tbkerusakan`
									WHERE id_kerusakan = '$id_kerusakan_sp'
								";
								$sql_kerusakan 		= mysql_query($query_kerusakan);
							 	$data_kerusakan 	= mysql_fetch_array($sql_kerusakan);
								$nama_kerusakan 	= $data_kerusakan['nama_kerusakan'];
								$harga_kerusakan 	= $data_kerusakan['harga_kerusakan'];
								//========================================================

								//cari data kerusakan
								$query_sp  = "SELECT *
									FROM `tbsparepart`
									WHERE id_sp = '$id_kerusakan_sp'
								";
								$sql_sp 	= mysql_query($query_sp);
							 	$data_sp 	= mysql_fetch_array($sql_sp);
								$nama_sp 	= $data_sp['nama_sp'];
								$harga_sp 	= $data_sp['harga_sp'];
								//========================================================
								
								//total biaya
								$total_biaya = $harga_kerusakan + $harga_sp + $total_biaya;
								//========================================================
							?>
							<td style="vertical-align: middle;"><?php echo $nama_kerusakan.''.$nama_sp; ?></td>
							<td style="vertical-align: middle; text-align: right;"><?php echo rupiah($harga_kerusakan.''.$harga_sp); ?></td>
						</tr>

						<?php $no++; } ?>
					</table>
					<table class="table table-hover" style="color: #000000;">
						<tr>
							<td colspan="2">Total Biaya : </td>
							<td style="vertical-align: middle; text-align: right;"><?php echo rupiah($total_biaya); ?></td>
						</tr>
					</table>
					<hr style="margin-top: 8px;">
					<table align="center">
						<tr>
							<td align="center" style=""></td>
							<td style="width: 400px;"></td>
							<td align="center">Hormat Saya</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
						<tr>
							<td align="center" style=""></td>
							<td style="width: 400px;"></td>
							<td align="center">Admin</td>
						</tr>
					</table>
				</div>
			</div>
			<!-- /.box-body -->
		</div>
	</section>
</body>


