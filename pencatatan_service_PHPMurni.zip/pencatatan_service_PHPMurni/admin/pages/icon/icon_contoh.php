
<section class="content">
	<div class="box box-primary">
		<div class="box-body">
			<i class="fa fa-check" style="font-size: 100px;"></i>
		</div>
	</div>
</section>