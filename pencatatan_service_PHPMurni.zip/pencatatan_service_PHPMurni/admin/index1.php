<?php
	session_start();
  $username_session       = $_SESSION['username'];
  $password_session       = $_SESSION['password'];
  $nama_pengguna_session  = $_SESSION['nama_pengguna'];
  $hak_akses_session      = $_SESSION['hak_akses'];

  echo "Username : ".$username_session."<br>";
?>