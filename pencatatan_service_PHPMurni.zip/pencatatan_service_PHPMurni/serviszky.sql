-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19 Jul 2019 pada 21.22
-- Versi Server: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `serviszky`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbkerusakan`
--

CREATE TABLE `tbkerusakan` (
  `id_kerusakan` varchar(25) NOT NULL,
  `nama_kerusakan` varchar(45) NOT NULL,
  `harga_kerusakan` int(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbkerusakan`
--

INSERT INTO `tbkerusakan` (`id_kerusakan`, `nama_kerusakan`, `harga_kerusakan`) VALUES
('RSK0001', 'INSTALL ULANG', 50000),
('RSK0002', 'SERVIS BIASA', 35000),
('RSK0003', 'SERVIS MATOT 1', 350000),
('RSK0004', 'SERVIS MATOT 2', 600000),
('RSK0005', 'IC POWER', 400000),
('RSK0006', 'FLASH BIOS', 30000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbkonsumen`
--

CREATE TABLE `tbkonsumen` (
  `id_konsumen` varchar(25) NOT NULL,
  `nama` varchar(25) NOT NULL,
  `jk` enum('Laki-Laki','Perempuan') NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `telp` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbkonsumen`
--

INSERT INTO `tbkonsumen` (`id_konsumen`, `nama`, `jk`, `alamat`, `telp`) VALUES
('KS0001', 'LOUIS', 'Laki-Laki', 'BEROK RAYA', '0810011331'),
('KS0002', 'CLEMENTINE', 'Perempuan', 'JL RAYA SITEBA', '0813002352'),
('KS0003', 'ADEL', 'Perempuan', 'BUKITTINGGI', '0815125632'),
('KS0004 ', 'LEXI', 'Laki-Laki', 'PAGANG', '0815125655');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbservis`
--

CREATE TABLE `tbservis` (
  `no_servis` varchar(25) NOT NULL,
  `id_konsumen` varchar(25) NOT NULL,
  `tgl_masuk` date NOT NULL,
  `tgl_keluar` date NOT NULL,
  `nama_barang` varchar(25) NOT NULL,
  `jenis_barang` varchar(25) NOT NULL,
  `desc_kerusakan` text NOT NULL,
  `kelengkapan` text NOT NULL,
  `status` enum('Belum Selesai','Telah Selesai','Telah Diambil') NOT NULL,
  `id_teknisi` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbservis`
--

INSERT INTO `tbservis` (`no_servis`, `id_konsumen`, `tgl_masuk`, `tgl_keluar`, `nama_barang`, `jenis_barang`, `desc_kerusakan`, `kelengkapan`, `status`, `id_teknisi`) VALUES
('SRV0001', 'KS0001', '2019-07-02', '2019-07-19', 'ACER E5-475G', 'LAPTOP', 'SERING MATI SENDIRI, SERING HANG, BATERAI CEPAT HABIS', 'UNIT DAN CHARGER', 'Telah Diambil', 'TK0001'),
('SRV0002', 'KS0002', '2019-07-03', '2019-07-19', 'ASUS ROG', 'LAPTOP', 'INSTAL ULANG, INSTAL GAME', 'UNIT, CHARGER DAN TAS', 'Telah Diambil', 'TK0003'),
('SRV0003', 'KS0003', '2019-07-30', '0000-00-00', 'EPSON L310', 'PRINTER', 'TERSERAH', 'UNIT SAJA', 'Belum Selesai', 'TK0001'),
('SRV0004', 'KS0001', '2019-07-19', '0000-00-00', 'CANON IP2700', 'PRINTER', 'TINTA PUTUS2', 'UNIT, KABEL DATA DAN KABEL POWER', 'Belum Selesai', ''),
('SRV0005', 'KS0002', '2019-07-15', '0000-00-00', 'PC DESKTOP CASE HITAM', 'PC DEKTOP', 'GANTI POWER SUPPLY', 'UNIT SAJA', 'Belum Selesai', ''),
('SRV0006', 'KS0003', '2019-07-15', '0000-00-00', 'ASUS, CANNON', 'LAPTOP, PRINTER', 'MATI TOTAL, TINTA PUTUS-PUTUS', '1 UNIT LAPTOP, 1 UNIT PRINTER', 'Belum Selesai', ''),
('SRV0007', 'KS0002', '2019-07-19', '0000-00-00', 'ASUS ROG', 'LAPTOP', 'MATI TOTAL', '1 UNIT LAPTOP', 'Belum Selesai', ''),
('SRV0008', 'KS0002', '2019-07-19', '0000-00-00', 'FASDFSAD', 'AASDF', 'SDFGSDFG', 'SDFGSDFG', 'Belum Selesai', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbsparepart`
--

CREATE TABLE `tbsparepart` (
  `id_sp` varchar(25) NOT NULL,
  `nama_sp` varchar(35) NOT NULL,
  `jenis_sp` varchar(25) NOT NULL,
  `harga_sp` int(25) NOT NULL,
  `qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbsparepart`
--

INSERT INTO `tbsparepart` (`id_sp`, `nama_sp`, `jenis_sp`, `harga_sp`, `qty`) VALUES
('SP0001', 'LED 14 INCH 30 PIN SLIM', 'LED ', 500000, 10),
('SP0002', 'LED 11.5 INCH 40 PIN NORMAL', 'LED ', 450000, 15),
('SP0003', 'KEYBOARD ACER 442', 'KEYBOARD', 250000, 20),
('SP0004', 'KEYBOARD ASUS X432Z', 'KEYBOARD', 280000, 5),
('SP0005', 'BATRAI TOSHIBA C640', 'BATRAI', 500000, 25),
('SP0006', 'BATRAI AXIOO PICO', 'BATRAI', 550000, 30),
('SP0007', 'KABEL FLEKSIBEL LED ACER ', 'KABEL FLEKSIBEL', 28000, 35);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbteknisi`
--

CREATE TABLE `tbteknisi` (
  `id_teknisi` varchar(25) NOT NULL,
  `nama_teknisi` varchar(25) NOT NULL,
  `jk_teknisi` enum('Laki-Laki','Perempuan') NOT NULL,
  `alamat_teknisi` varchar(40) NOT NULL,
  `telp_teknisi` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbteknisi`
--

INSERT INTO `tbteknisi` (`id_teknisi`, `nama_teknisi`, `jk_teknisi`, `alamat_teknisi`, `telp_teknisi`) VALUES
('TK0001', 'PARZIVAL', 'Laki-Laki', 'BUKITTINGGI', '0823346323'),
('TK0002', 'ART3MIS', 'Perempuan', 'SOLOK', '0823346457'),
('TK0003', 'HAMZAH', 'Laki-Laki', 'SITEBA', '0810011487');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbtransaksi`
--

CREATE TABLE `tbtransaksi` (
  `id_transaksi` int(11) NOT NULL,
  `no_servis` varchar(25) NOT NULL,
  `id_kerusakan_sp` varchar(25) NOT NULL,
  `jenis_servis` enum('Kerusakan','Sparepart') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ROW_FORMAT=COMPACT;

--
-- Dumping data untuk tabel `tbtransaksi`
--

INSERT INTO `tbtransaksi` (`id_transaksi`, `no_servis`, `id_kerusakan_sp`, `jenis_servis`) VALUES
(1, 'SRV0001', 'RSK0001', 'Kerusakan'),
(2, 'SRV0001', 'SP0001', 'Sparepart'),
(21, 'SRV0001', 'RSK0005', 'Kerusakan'),
(22, 'SRV0001', 'SP0003', 'Sparepart'),
(23, 'SRV0003', 'RSK0006', 'Kerusakan'),
(24, 'SRV0002', 'RSK0003', 'Kerusakan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbuser`
--

CREATE TABLE `tbuser` (
  `username` varchar(25) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama_user` varchar(25) NOT NULL,
  `hakakses` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbuser`
--

INSERT INTO `tbuser` (`username`, `password`, `nama_user`, `hakakses`) VALUES
('admin', 'admin', 'Zaki', 'admin'),
('user', 'user', 'tester2', 'user');

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_servis`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `v_servis` (
`no_servis` varchar(25)
,`id_konsumen` varchar(25)
,`tgl_masuk` date
,`tgl_keluar` date
,`nama_barang` varchar(25)
,`jenis_barang` varchar(25)
,`desc_kerusakan` text
,`kelengkapan` text
,`status` enum('Belum Selesai','Telah Selesai','Telah Diambil')
,`id_teknisi` varchar(25)
,`nama` varchar(25)
,`jk` enum('Laki-Laki','Perempuan')
,`alamat` varchar(40)
,`telp` varchar(15)
,`nama_teknisi` varchar(25)
,`jk_teknisi` enum('Laki-Laki','Perempuan')
,`alamat_teknisi` varchar(40)
,`telp_teknisi` varchar(15)
);

-- --------------------------------------------------------

--
-- Struktur untuk view `v_servis`
--
DROP TABLE IF EXISTS `v_servis`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_servis`  AS  select `tbservis`.`no_servis` AS `no_servis`,`tbservis`.`id_konsumen` AS `id_konsumen`,`tbservis`.`tgl_masuk` AS `tgl_masuk`,`tbservis`.`tgl_keluar` AS `tgl_keluar`,`tbservis`.`nama_barang` AS `nama_barang`,`tbservis`.`jenis_barang` AS `jenis_barang`,`tbservis`.`desc_kerusakan` AS `desc_kerusakan`,`tbservis`.`kelengkapan` AS `kelengkapan`,`tbservis`.`status` AS `status`,`tbservis`.`id_teknisi` AS `id_teknisi`,`tbkonsumen`.`nama` AS `nama`,`tbkonsumen`.`jk` AS `jk`,`tbkonsumen`.`alamat` AS `alamat`,`tbkonsumen`.`telp` AS `telp`,`tbteknisi`.`nama_teknisi` AS `nama_teknisi`,`tbteknisi`.`jk_teknisi` AS `jk_teknisi`,`tbteknisi`.`alamat_teknisi` AS `alamat_teknisi`,`tbteknisi`.`telp_teknisi` AS `telp_teknisi` from ((`tbservis` join `tbkonsumen` on((`tbservis`.`id_konsumen` = `tbkonsumen`.`id_konsumen`))) join `tbteknisi` on((`tbservis`.`id_teknisi` = `tbteknisi`.`id_teknisi`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbkerusakan`
--
ALTER TABLE `tbkerusakan`
  ADD PRIMARY KEY (`id_kerusakan`);

--
-- Indexes for table `tbkonsumen`
--
ALTER TABLE `tbkonsumen`
  ADD PRIMARY KEY (`id_konsumen`);

--
-- Indexes for table `tbservis`
--
ALTER TABLE `tbservis`
  ADD PRIMARY KEY (`no_servis`),
  ADD KEY `id_konsumen` (`id_konsumen`);

--
-- Indexes for table `tbsparepart`
--
ALTER TABLE `tbsparepart`
  ADD PRIMARY KEY (`id_sp`);

--
-- Indexes for table `tbteknisi`
--
ALTER TABLE `tbteknisi`
  ADD PRIMARY KEY (`id_teknisi`);

--
-- Indexes for table `tbtransaksi`
--
ALTER TABLE `tbtransaksi`
  ADD PRIMARY KEY (`id_transaksi`);

--
-- Indexes for table `tbuser`
--
ALTER TABLE `tbuser`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbtransaksi`
--
ALTER TABLE `tbtransaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
