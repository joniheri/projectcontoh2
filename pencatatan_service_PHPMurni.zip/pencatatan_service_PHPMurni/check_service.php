<div class="table-responsive no-padding">
	<h3 align="center">Hasil Pencarian</h3>
	<table class="table table-hover">
		<tr>
			<td style="width: 150px; vertical-align: middle;">No Service </td>
			<td style="width: 10px; vertical-align: middle;">:</td>
			<td style="vertical-align: middle;"><?php echo $no_service_post; ?></td>
		</tr>
		<tr>
			<td style="vertical-align: middle;">Nama Konsumen</td>
			<td style="vertical-align: middle;">:</td>
			<td style="vertical-align: middle;"><?php echo $nama_konsumen; ?></td>
		</tr>
		<tr>
			<td style="vertical-align: middle;">Nama Barang</td>
			<td style="vertical-align: middle;">:</td>
			<td style="vertical-align: middle;"><?php echo $nama_barang; ?></td>
		</tr>
		<tr>
			<td style="vertical-align: middle;">Status Service</td>
			<td style="vertical-align: middle;">:</td>
			<td style="vertical-align: middle;"><?php echo $status_service; ?></td>
		</tr>
		<tr>
			<td style="vertical-align: middle;">Total Biaya</td>
			<td style="vertical-align: middle;">:</td>
			<td style="vertical-align: middle;"><?php echo rupiah($total_biaya); ?></td>
		</tr>
	</table>
</div>