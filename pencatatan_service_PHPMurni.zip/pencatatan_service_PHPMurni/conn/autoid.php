<?php
// id konsumen
$sql_cari_id = "SELECT MAX(id_konsumen) FROM tbkonsumen";
$cari_id = mysql_query($sql_cari_id) or die (mysql_error());
$data_id = mysql_fetch_array($cari_id);

if ($data_id) {
	$nilai_id = substr($data_id[0], 2);
	// echo $nilai_id; die;
	$id = (int) $nilai_id;
	$id = $id + 1;
	$auto_idk = "KS".str_pad($id,4,"0",STR_PAD_LEFT);
}
else {
	$auto_idk = "KS0001";
}

// id teknisi
$sql_cari_id = "SELECT MAX(id_teknisi) FROM tbteknisi";
$cari_id = mysql_query($sql_cari_id) or die (mysql_error());
$data_id = mysql_fetch_array($cari_id);

if ($data_id) {
	$nilai_id = substr($data_id[0], 2);
	// echo $nilai_id; die;
	$id = (int) $nilai_id;
	$id = $id + 1;
	$auto_idt = "TK".str_pad($id,4,"0",STR_PAD_LEFT);
}
else {
	$auto_idt = "TK0001";
}

// id sp 
$sql_cari_id = "SELECT MAX(id_sp) FROM tbsparepart";
$cari_id = mysql_query($sql_cari_id) or die (mysql_error());
$data_id = mysql_fetch_array($cari_id);

if ($data_id) {
	$nilai_id = substr($data_id[0], 2);
	// echo $nilai_id; die;
	$id = (int) $nilai_id;
	$id = $id + 1;
	$auto_idsp = "SP".str_pad($id,4,"0",STR_PAD_LEFT);
}
else {
	$auto_idsp = "SP0001";
}

// id rusak
$sql_cari_id = "SELECT MAX(id_kerusakan) FROM tbkerusakan";
$cari_id = mysql_query($sql_cari_id) or die (mysql_error());
$data_id = mysql_fetch_array($cari_id);

if ($data_id) {
	$nilai_id = substr($data_id[0], 3);
	// echo $nilai_id; die;
	$id = (int) $nilai_id;
	$id = $id + 1;
	$auto_idrsk = "RSK".str_pad($id,4,"0",STR_PAD_LEFT);
}
else {
	$auto_idrsk = "RSK0001";
}

// no servis masuk
$sql_cari_id = "SELECT MAX(no_servis) FROM tbservis";
$cari_id = mysql_query($sql_cari_id) or die (mysql_error());
$data_id = mysql_fetch_array($cari_id);

if ($data_id) {
	$nilai_id = substr($data_id[0], 3);
	// echo $nilai_id; die;
	$id = (int) $nilai_id;
	$id = $id + 1;
	$auto_nosmsk = "SRV".str_pad($id,4,"0",STR_PAD_LEFT);
}
else {
	$auto_nosmsk = "SRV0001";
}

?>