<?php

	/*
	$username_post = $_POST['username'];
	$password_post = $_POST['password'];
	echo 'Username : '.$username_post;
	echo "<br>";
	echo 'Password : '.$password_post;	

	if($username_post == "admin" && $password_post == "admin"){
		echo "<script>alert('Anda berhasil Log In');</script>";
		echo "<meta http-equiv='refresh' content='0; url=admin/index.php'>";
	}
	else{
		echo "<script>alert('Login GAGAL');</script>";
		echo "<meta http-equiv='refresh' content='0; url=index.php'>";
	}
	*/
	//include "admin/index.php"
	include 'conn/koneksi.php';
	if(isset($_POST['log'])) {
		$user 		= mysql_real_escape_string($_POST['username']);
		$pass 		= mysql_real_escape_string($_POST['password']);
		//$web_login 	= mysql_real_escape_string($_POST['web_login']);

		$sql 		= mysql_query("SELECT * FROM tbuser where username='$user' and password='$pass'");
		$data 		= mysql_fetch_array($sql);
		$username 	= $data['username'];
		$password 	= $data['password'];
		$nama_user 	= $data['nama_user'];
		$hak_akses 	= $data['hakakses'];

		if ($user==$username && $pass==$password) {
			
			session_start();
			$_SESSION['username'] 			= $user;
			$_SESSION['password']			= $pass;
			$_SESSION['nama_user'] 			= $nama_user;
			$_SESSION['hak_akses'] 			= $hak_akses;

			echo "<script>alert('Login sebagai admin BERHASIL!');</script>";
			echo "<meta http-equiv='refresh' content='0; url=admin'>";
		}
		else {
			echo "<script>alert('Username atau password anda SALAH, Silahkan login kembali.');</script>";
			echo "<meta http-equiv='refresh' content='0; url=../serviszky'>";
		}
	}
?>