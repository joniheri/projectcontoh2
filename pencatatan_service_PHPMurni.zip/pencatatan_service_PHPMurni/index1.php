<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>E-Dokumen SKC Barat</title>
  <?php
    include 'inc/head.php';
  ?>
</head>
<!-- ADD THE CLASS layout-top-nav TO REMOVE THE SIDEBAR. -->
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

  <header class="main-header">
    <?php include 'inc/menu_header.php'; ?>
  </header>

  <!-- Full Width Column -->
  <div class="content-wrapper">
    <div class="container">
      
      <!-- Main content -->
      <section class="content">
        <!-- About Me Box -->
          <div class="box box-primary">
            <!-- Main content -->
            <?php
              error_reporting(0);
              switch($_GET['page'])
              {
                // Home
                default:
                include "pages/home.php";
                break;
                //==================================================

                // Data Produk
                case "pengumuman";
                include "pages/pengumuman.php";
                break;
                //==================================================
                }

            ?>
            <!-- End main content -->
          </div>
      </section>
      <!-- /.content -->
    </div>
    <!-- /.container -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
      </div>
      <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="joncode.blogspot.com"> Jon Code</a>.</strong> All rights reserved.
    </div>
    <!-- /.container -->
  </footer>
</div>
<!-- ./wrapper -->

<!-- jQuery 3 -->
<?php
  include 'inc/javascript.php';
?>
<!-- jQuery -->
</body>
</html>
