<nav class="navbar navbar-static-top">
  <div class="container">
    <div class="navbar-header">
      <a href="index.php" class="navbar-brand"><b>E-Dokumen</b> SKCB</a>
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse">
        <i class="fa fa-bars"></i>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse pull-left" id="navbar-collapse">
      <ul class="nav navbar-nav">
        <li class=""><a href="index.php">Home</a></li>
        <li class=""><a href="?page=pengumuman">Pengumuman</a></li>
      </ul>
      <form class="navbar-form navbar-left" role="search">
        <div class="form-group">
          <input type="text" class="form-control" id="navbar-search-input" placeholder="Cari">
        </div>
      </form>
    </div>
    <!-- /.navbar-collapse -->

    <!-- Navbar Right Menu -->
    <div class="navbar-custom-menu">
      <ul class="nav navbar-nav">

        <!-- Notifications Menu -->
        <li class="dropdown notifications-menu">
          <!-- Menu toggle button -->
          <a href="#" class="dropdown-toggle" data-toggle="dropdown">
            <i class="fa fa-user"></i> Masuk <span class="caret"></span>
          </a>
          <ul class="dropdown-menu">
            <li class="header">Pilih hak akses</li>
            <li>
              <!-- Inner Menu: contains the notifications -->
              <ul class="menu">
                <li>
                  <a href="login.php?hak_akses=Admin">
                    <i class="fa fa-user-secret text-aqua"></i> Admin
                  </a>
                </li>
                <li>
                  <a href="login.php?hak_akses=Masyarakat">
                    <i class="fa fa-users text-aqua"></i> Masyarakat
                  </a>
                </li>
                <!-- end notification -->
              </ul>
            </li>
            <!--
            <li class="footer"><a href="#">View all</a></li>
            -->
          </ul>
        </li>
      </ul>
    </div>
    <!-- /.navbar-custom-menu -->

  </div>
  <!-- /.container-fluid -->
</nav>